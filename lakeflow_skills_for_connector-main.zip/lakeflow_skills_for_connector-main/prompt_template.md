# Prompt Template: Lakeflow Pipeline Request

## Purpose
This template serves as the intake form for ALL new Lakeflow pipeline requests. The agent MUST collect these parameters before generating a design document. Supports both **batch** (full_refresh) and **streaming** (incremental) processing modes by default.

---

## Fill-In Template

```
Read: /Workspace/Users/<<your_email>>/.assistant/lakeflow_skills_for_connector/.assistant_instructions.md

=== PIPELINE REQUEST ===

Project Name         : <<project_name>>
Source System        : <<source_system_name>> (e.g., SQL Server, Oracle, PostgreSQL, Salesforce, MySQL)
Ingestion Method     : <<ingestion_method>> (CDC-based | Query-based)
Cloud Provider       : <<cloud_provider>> (AWS | Azure | GCP)
Compute              : Serverless
Languages            : PySpark / SQL
Processing Modes     : Both (full_refresh + incremental — ALL layers use Streaming Tables)

=== CATALOG & SCHEMA CONFIGURATION ===

Bronze               : <<bronze_catalog>>.<<bronze_schema>>
Silver               : <<silver_catalog>>.<<silver_schema>>
Gold                 : <<gold_catalog>>.<<gold_schema>>
DQX                  : <<dqx_catalog>>.<<dqx_schema>>

=== REFERENCE ASSETS ===

Existing Pipeline/Job for Reference  : <<pipeline_id or job_id or N/A>>
Source Mapping Document Path         : <<Volume path or N/A>>
Silver SQL/Design Document Path      : <<Volume path or N/A>>
Gold SQL/Design Document Path        : <<Volume path or N/A>>

NOTE: Source Tables List, Primary Keys, Foreign Keys, and Timestamp Column
      MUST be defined in the mapping/design document (not in this intake form).

=== INGESTION DETAILS (Lakeflow Connect) ===

Connection Name      : <<UC_connection_name>>
Source Schema        : <<source_database_schema>> (e.g., public, dbo)
Ingestion Method     : <<CDC-based | Query-based>>
Gateway              : <<gateway_name or N/A>> (CDC-based only)
Staging Volume       : <<staging_volume_path or N/A>> (CDC-based only)
Cursor Column        : <<cursor_column_name or N/A>> (Query-based only)

=== TRANSFORMATION REQUIREMENTS ===

Silver Transformations:
  - <<table_name>>: <<transformation_description>>
  - <<table_name>>: <<transformation_description>>

Gold Aggregations (Streaming Tables):
  - <<gold_entity_name>>: <<aggregation_description>>
  - <<gold_entity_name>>: <<aggregation_description>>

=== DQX CONFIGURATION ===

DQX Validation Pairs:
  - Source vs Bronze   : YES/NO
  - Bronze vs Silver   : YES/NO
  - Silver vs Gold     : YES/NO

DQX Alert Recipients     : <<email_1, email_2, ...>>

=== ORCHESTRATION ===

Job Name             : <<orchestration_job_name>>
Initial Run Mode     : Full Refresh (both pipelines)
Subsequent Run Mode  : Incremental (both pipelines)
Schedule             : <<cron_expression or manual>>
Notification Emails  : <<email_1, email_2, ...>>

1. Please avoid hard-coding values in the notebook, parameterize the notebook inputs.
2. Create .md design document file with detailed steps and wait for my approval before creating any Lakeflow jobs/SDP/Lakebase pipelines 
3. Build an orchestration job/pipeline for this process by adding a dependency so that if any job fails, the next job in the orchestration won’t trigger
4. orchestration should do Full Refresh when we run first time and do incremental load from next time
5. Add flag parameter orchestration which will decide whether orchestration run with ‘Full Refresh’ or ‘Incremental load’ 
```

---

## Filled Example (Generic — Replace with Actual Values)

```
Read: /Workspace/Users/<<your_email>>/.assistant/lakeflow_skills_for_connector/.assistant_instructions.md

=== PIPELINE REQUEST ===

Project Name         : <<SourceSystem>>_migration
Source System        : <<SourceSystem>> (e.g., PostgreSQL, SQL Server, MySQL, Oracle, Salesforce)
Ingestion Method     : <<CDC-based | Query-based>>
Cloud Provider       : <<AWS | Azure | GCP>>
Compute              : Serverless
Languages            : PySpark / SQL
Processing Modes     : Both (full_refresh + incremental)

=== CATALOG & SCHEMA CONFIGURATION ===

Bronze               : <<catalog_name>>.<<source_system>>_bronze
Silver               : <<catalog_name>>.<<source_system>>_silver
Gold                 : <<catalog_name>>.<<source_system>>_gold
DQX                  : <<catalog_name>>.<<source_system>>_dqx

=== REFERENCE ASSETS ===

Existing Pipeline/Job for Reference  : <<pipeline_id | job_id | N/A>>
Source Mapping Document Path         : <</Volumes/catalog/schema/volume/Source/ | N/A>>
Silver SQL/Design Document Path      : <</Volumes/catalog/schema/volume/Silver/ | N/A>>
Gold SQL/Design Document Path        : <</Volumes/catalog/schema/volume/Gold/ | N/A>>

=== INGESTION DETAILS (Lakeflow Connect) ===

Connection Name      : <<uc_connection_name>>
Source Schema        : <<source_schema>> (e.g., public, dbo, hr)
Ingestion Method     : <<CDC-based | Query-based>>
Gateway              : <<gateway_name | N/A>> (CDC-based only)
Staging Volume       : <<staging_volume_path | N/A>> (CDC-based only)
Cursor Column        : <<cursor_column_name | N/A>> (Query-based only)

=== TRANSFORMATION REQUIREMENTS ===

Silver Transformations:
  - Transformation description available in Silver SQL/Design Document
  - OR list individual table transformations here

Gold Aggregations (Streaming Tables):
  - Aggregation description available in Gold SQL/Design Document
  - OR list individual gold entity descriptions here

=== DQX CONFIGURATION ===

DQX Validation Pairs:
  - Source vs Bronze   : YES/NO
  - Bronze vs Silver   : YES/NO
  - Silver vs Gold     : YES/NO

DQX Alert Recipients     : <<email_1, email_2, ...>>

=== ORCHESTRATION ===

Job Name             : <<source_system>>_migration_orchestration
Initial Run Mode     : Full Refresh
Subsequent Run Mode  : Incremental
Schedule             : <<cron_expression or manual>>
Notification Emails  : <<email_1, email_2, ...>>

1. Please avoid hard-coding values in the notebook, parameterize the notebook inputs.
2. Create .md design document file with detailed steps and wait for my approval before creating any Lakeflow jobs/SDP/Lakebase pipelines 
3. Build an orchestration job/pipeline for this process by adding a dependency so that if any job fails, the next job in the orchestration won’t trigger
4. orchestration should do Full Refresh when we run first time and do incremental load from next time
5. Add flag parameter orchestration which will decide whether orchestration run with ‘Full Refresh’ or ‘Incremental load’ 
```

---

## Parameter Rules

### REQUIRED Parameters (agent MUST collect before proceeding)
| Parameter | Validation | Default |
|---|---|---|
| Project Name | Non-empty string, snake_case | None — must ask |
| Source System | Supported system (PostgreSQL, SQL Server, MySQL, Oracle, Salesforce, etc.) | None — must ask |
| Ingestion Method | One of: CDC-based, Query-based | Query-based |
| Cloud Provider | One of: AWS, Azure, GCP | AWS |
| All Catalog/Schema pairs | Valid UC identifiers (catalog.schema format) | None — must ask |
| Connection Name | Existing UC CONNECTION name | None — must ask |

### REQUIRED in Mapping/Design Document (NOT collected in this template)
| Parameter | Validation | Default |
|---|---|---|
| Source Tables List | At least one table | None — must be in mapping doc |
| Primary Keys | At least one PK per table | None — must be in mapping doc |
| Timestamp Column | Column name for watermark tracking | updated_at |
| Foreign Keys | Valid references to tables in source list | N/A (optional) |

### OPTIONAL Parameters (use defaults if not provided)
| Parameter | Default |
|---|---|
| Reference Pipeline/Job | N/A |
| Mapping Document Paths | N/A |
| Gateway | Required only for CDC-based |
| Staging Volume | Required only for CDC-based |
| Cursor Column | Required only for Query-based |
| DQX Alert Recipients | Must ask if DQX enabled |
| Schedule | manual |

### run_mode Behavior (Applies to ALL Layers)

| run_mode | Bronze | Silver | Gold | DQX |
|---|---|---|---|---|
| **full_refresh** | Full snapshot from source | Truncate + replay ALL bronze | Truncate + replay ALL silver | Validate complete dataset |
| **incremental** | Only new/changed records | Only new bronze records | Only new silver records | Validate current state |

**Architecture**: ALL layers (Bronze, Silver, Gold) use Streaming Tables (`@dp.table()` / `CREATE OR REFRESH STREAMING TABLE`).
- Same code handles both modes natively — the `full_refresh` flag at runtime controls behavior.
- NEVER use Materialized Views at any layer.

### Ingestion Method Dependencies

| Method | Requires Gateway | Requires Staging Volume | Requires Cursor Column |
|---|---|---|---|
| CDC-based | YES | YES | NO |
| Query-based | NO | NO | YES |

### Validation Rules
1. **Catalog names** must follow Unity Catalog naming: lowercase, underscores, no spaces
2. **Connection** must exist as a UC CONNECTION before pipeline creation
3. **Primary keys** must be specified for EVERY source table (in mapping doc)
4. **CDC-based** ingestion MUST have gateway and staging volume
5. **Query-based** ingestion MUST have cursor column for incremental
6. **At least one DQX pair** must be YES if DQX is requested
7. **Alert recipients** required if any DQX pair is YES

---

## Agent Behavior After Template Collection

1. Validate all REQUIRED parameters are present
2. Apply defaults for missing OPTIONAL parameters
3. Verify ingestion method dependencies are satisfied
4. If reference pipeline/job provided: read it using `readAssetById`
5. If mapping documents provided: read and extract table metadata
6. Generate design document using `design_template.md`
7. **WAIT for user approval** before building any artifacts

---

## Architecture Output (What Gets Created)

| # | Artifact | Type | Description |
|---|---|---|---|
| 1 | `{source_system}_lakeflow_ingestion` | Lakeflow Connect Pipeline | `ingestion_definition` — no code files |
| 2 | `{source_system}_sdp_pipeline` | SDP Pipeline | Libraries: silver .py + gold .sql |
| 3 | `silver_transformations.py` | Python file | `@dp.table()` + `spark.readStream` |
| 4 | `gold_aggregations.sql` | SQL file | `CREATE OR REFRESH STREAMING TABLE` + `STREAM()` |
| 5 | `{source_system}_dqx_validation` | Notebook | Batch validation across layers |
| 6 | `{source_system}_dqx_alerts` | Notebook | Alert notifications |
| 7 | `{source_system}_ingestion_orchestration` | Lakeflow Job | DAG: ingestion → transform → DQX → alerts |

---

## Processing Modes — Both Supported by Default

| Mode | When Used | Ingestion | Transformation | Gold |
|------|-----------|-----------|----------------|------|
| **full_refresh** | First run, data recovery | Full snapshot | Truncate + recompute | Full recompute |
| **incremental** | Scheduled runs | Cursor/watermark delta | From checkpoint | Full recompute (MVs) |

**Key**: No code changes between modes. Pipeline `full_refresh` flag controls everything at runtime.
Both modes are a first-class feature — every pipeline supports them from day one.
