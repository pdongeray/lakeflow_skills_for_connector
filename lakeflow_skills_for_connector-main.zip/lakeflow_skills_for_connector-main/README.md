# Lakeflow Skills for Connector

A complete, agent-driven blueprint for building **production-grade Lakeflow pipelines on Databricks**. These files are a set of "skills" that guide a Databricks Assistant agent through collecting requirements, generating a design document, and building a two-pipeline medallion architecture using **Lakeflow Connect** (managed ingestion) + **SDP** (transformations).

## Architecture

**Two-Pipeline design** — every generated solution supports both **batch** (`full_refresh`) and **streaming** (`incremental`) modes with no code-level conditionals:

```
┌────────────────────────────────────────────────────┐
│ Pipeline 1: Lakeflow Connect Managed Ingestion      │
│ • ingestion_definition (no code files)              │
│ • Source → Bronze (auto-managed Streaming Tables)   │
└──────────────────────┬─────────────────────────────┘
                       ▼
┌────────────────────────────────────────────────────┐
│ Pipeline 2: SDP Transformation Pipeline             │
│ • Bronze → Silver (Streaming Tables, @dp.table)     │
│ • Silver → Gold (Streaming Tables + readStream)     │
└──────────────────────┬─────────────────────────────┘
                       ▼
        DQX Validation (batch) → DQX Alerts
```

- Identical pipeline code across **AWS, Azure, and GCP** — only External Location and Storage Credential differ.
- **Serverless** compute for all tasks; **PySpark / SQL** only.
- **Gold = Streaming Tables always** (never Materialized Views), so true incremental works at every layer.

## Design-First Protocol

```
USER REQUEST → COLLECT (prompt_template) → DESIGN (design_template) → AWAIT APPROVAL → BUILD ARTIFACTS
```

Pipelines, notebooks, and jobs are **never** created without a design document the user has approved.

## Repository Contents

| File | Purpose | Phase |
|---|---|---|
| `.assistant_instructions.md` | Master instructions governing how the agent uses the skills | — |
| `prompt_template.md` | Intake form + parameter rules | Collect |
| `skills/design_template.md` | Design-document generator | Design |
| `skills/bronze_cdc_ingestion.md` | Lakeflow Connect ingestion + CDC patterns | Build |
| `skills/silver_transformation.md` | Bronze → Silver streaming tables | Build |
| `skills/gold_aggregation.md` | Silver → Gold streaming tables + aggregations | Build |
| `skills/dqx_validation.md` | Cross-layer data-quality validation (batch) | Validate |
| `skills/dqx_alerts.md` | Alert creation + subscriptions | Alert |
| `skills/orchestration.md` | Job DAG + scheduling | Orchestrate |

## Usage

1. In the Databricks workspace, place this folder under your assistant skills directory (e.g. `/Workspace/Users/<you>/.assistant/lakeflow_skills_for_connector/`).
2. Point the agent at `.assistant_instructions.md`.
3. Fill in `prompt_template.md` with your pipeline request (source system, catalogs/schemas, ingestion method, DQX pairs, orchestration).
4. Review and approve the generated design document.
5. The agent builds the ingestion pipeline, SDP transformation pipeline, DQX validation/alert notebooks, and the orchestration job.

## Key Conventions

- **API**: `from pyspark import pipelines as dp` (never `import dlt`).
- **Parameters**: `spark.conf.get("param")` — everything parameterized, nothing hard-coded.
- **Files**: standalone `.py` / `.sql` (no `%sql` magic notebooks).
- **Clustering**: `cluster_by_auto=True` on all tables.
- **DQX**: batch-only, `PASS`/`FAIL`, results table never truncated.
- **Orchestration**: `ingestion → transformation → DQX → alerts`, first run full refresh, subsequent runs incremental.
