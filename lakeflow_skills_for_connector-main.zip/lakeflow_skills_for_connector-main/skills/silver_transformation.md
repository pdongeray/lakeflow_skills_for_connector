# Silver Transformation Skill

## Purpose
This skill covers Silver Layer pipeline construction using Spark Declarative Pipelines (SDP). The Silver layer cleanses, transforms, and enriches Bronze data for downstream analytics. Supports both **batch** (full_refresh) and **streaming** (incremental) modes.

---

## File Structure (Standalone .py file — NOT a notebook with %sql magic)

```python
# silver_transformations.py
# Single Python file used as a pipeline library
# NO dbutils.widgets — use spark.conf.get() for pipeline parameters
# NO %sql magic — pure Python
```

---

## Critical Rules

| Rule | Description |
|---|---|
| API | `from pyspark import pipelines as dp` (NOT `import dlt`) |
| Table Type | Streaming Table (`@dp.table()`) for ALL silver tables |
| Read Method | `spark.readStream.table()` for streaming from bronze |
| Parameters | `spark.conf.get("param_name")` — NOT `dbutils.widgets` |
| No Magic | No `%sql` magic — standalone `.py` file |
| Clustering | `cluster_by_auto=True` on ALL silver tables |
| Both Modes | No code-level conditionals — framework handles full_refresh vs incremental |
| Source Reference | Fully qualified table names: `{bronze_catalog}.{bronze_schema}.{table}` |
| Delete Filter | Remove DELETE operations if CDC source (check `_operation_type`) |

---

## run_mode Behavior (full_refresh vs incremental)

The SAME silver code supports BOTH modes — controlled by the `run_mode` job parameter at runtime:

| run_mode | Silver Behavior | What Gets Processed |
|---|---|---|
| **full_refresh** | Truncate silver tables + replay ALL bronze records from scratch | Everything — complete rebuild |
| **incremental** | Resume from last checkpoint offset | ONLY new/changed records since last run |

**Key Insight**: `@dp.table()` + `spark.readStream.table()` handles BOTH modes natively:
- **full_refresh**: Framework truncates the streaming table and replays ALL data from bronze
- **incremental**: Framework resumes from last checkpoint, processing only new records
- **No code changes** between modes — the pipeline `full_refresh` flag controls behavior
- **Same pattern across ALL layers** (Bronze, Silver, Gold) for consistent incremental processing

---

## Python Pattern (Primary — for standalone .py files)

### Configuration & Imports

```python
from pyspark import pipelines as dp
from pyspark.sql import functions as F
from pyspark.sql.types import *

# Pipeline parameters (from pipeline configuration block)
BRONZE_CATALOG = spark.conf.get("bronze_catalog")
BRONZE_SCHEMA = spark.conf.get("bronze_schema")
SOURCE_SYSTEM = spark.conf.get("source_system")
```

### Single Table Pattern

```python
# Pattern: One @dp.table() per source table
# Replace {table_name}, {pk_column}, and transformations with actual values from mapping doc

@dp.table(
    name="silver_{table_name}",
    comment="Cleansed {table_name} data with standardized fields",
    cluster_by_auto=True,
    table_properties={"quality": "silver", "source_system": SOURCE_SYSTEM}
)
def silver_{table_name}():
    return (
        spark.readStream.table(f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}")
        # Apply domain-specific transformations here:
        # - Standardize text: F.initcap(), F.lower(), F.trim()
        # - Clean phone/email: F.regexp_replace()
        # - Cast types: .cast("decimal(10,2)")
        # - Derive columns: F.concat_ws(), F.when()
        .filter(F.col("{pk_column}").isNotNull())  # Always filter null PKs
    )
```

### Multi-Source Join Pattern

```python
# Pattern: Stream a fact table and join with dimension tables
# Replace table names, join keys, and selected columns with actual values

@dp.table(
    name="silver_{fact_table}_enriched",
    comment="Enriched {fact_table} with dimension lookups",
    cluster_by_auto=True,
    table_properties={"quality": "silver"}
)
def silver_{fact_table}_enriched():
    # Stream the main fact table
    fact = spark.readStream.table(f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{fact_table}")
    # Broadcast join with small dimension tables (static read)
    dimension = spark.read.table(f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{dim_table}")
    
    return (
        fact
        .join(F.broadcast(dimension), "{join_key}", "left")
        .select(
            fact["{fact_pk}"],
            fact["{join_key}"],
            dimension["{dim_column}"].alias("{alias_name}"),
            # Add more columns as needed
        )
    )
```

### CDC Delete Filter Pattern (when reading from CDC bronze)

```python
# Pattern: Filter out DELETE operations from CDC source before transforming
# Apply to ALL tables when ingestion is CDC-based

@dp.table(
    name="silver_{table_name}",
    comment="Active {table_name} only (deleted records filtered)",
    cluster_by_auto=True,
    table_properties={"quality": "silver"}
)
def silver_{table_name}():
    return (
        spark.readStream.table(f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}")
        # CRITICAL: Filter out deleted records if CDC source
        .filter(F.coalesce(F.col("_operation_type"), F.lit("INSERT")) != "DELETE")
        # Apply domain-specific transformations
        .filter(F.col("{pk_column}").isNotNull())
    )
```

---

## SQL Pattern (Alternative — for standalone .sql files)

```sql
-- silver_transformations.sql
-- Works for BOTH full_refresh and incremental modes
-- Replace {table_name}, {pk_column}, and column lists with actual values

-- Pattern: Basic silver table with cleansing
CREATE OR REFRESH STREAMING TABLE silver_{table_name}
CLUSTER BY AUTO
TBLPROPERTIES ('quality' = 'silver')
COMMENT 'Cleansed {table_name} data'
AS SELECT
  {pk_column},
  -- Apply domain-specific transformations:
  -- initcap(trim(col)) for names
  -- lower(trim(col)) for emails
  -- CAST(col AS DECIMAL(10,2)) for amounts
  -- regexp_replace(col, '[^0-9+]', '') for phones
  *  -- replace with explicit column list from mapping doc
FROM STREAM(${bronze_catalog}.${bronze_schema}.{table_name})
WHERE {pk_column} IS NOT NULL;

-- Pattern: With CDC delete filter (use when ingestion is CDC-based)
CREATE OR REFRESH STREAMING TABLE silver_{table_name}
CLUSTER BY AUTO
TBLPROPERTIES ('quality' = 'silver')
AS SELECT
  {pk_column},
  -- Apply transformations from mapping document
  *  -- replace with explicit column list
FROM STREAM(${bronze_catalog}.${bronze_schema}.{table_name})
WHERE {pk_column} IS NOT NULL
  AND coalesce(_operation_type, 'INSERT') != 'DELETE';
```

---

## Data Quality Expectations

```python
# Pattern: Add inline data quality expectations to drop invalid records
# Define expectations based on your domain's business rules

@dp.table(
    name="silver_{table_name}",
    comment="Validated {table_name} records",
    cluster_by_auto=True,
    table_properties={"quality": "silver"}
)
@dp.expect_all_or_drop({
    "valid_pk": "{pk_column} IS NOT NULL",
    "valid_fk": "{fk_column} IS NOT NULL",  # if applicable
    "valid_date": "{date_column} IS NOT NULL AND {date_column} <= current_date()",
    "positive_amount": "{amount_column} >= 0"  # if applicable
})
def silver_{table_name}():
    return (
        spark.readStream.table(f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}")
        .withColumn("{date_column}", F.to_date("{date_column}"))
        .withColumn("{amount_column}", F.col("{amount_column}").cast("decimal(12,2)"))
    )
```

---

## Common Transformations Reference

| Operation | PySpark | SQL |
|-----------|---------|-----|
| Standardize name | `F.initcap(F.trim(col))` | `initcap(trim(col))` |
| Clean email | `F.lower(F.trim(col))` | `lower(trim(col))` |
| Clean phone | `F.regexp_replace(col, "[^0-9+]", "")` | `regexp_replace(col, '[^0-9+]', '')` |
| Cast decimal | `col.cast("decimal(10,2)")` | `CAST(col AS DECIMAL(10,2))` |
| Default null | `F.coalesce(col, F.lit(default))` | `coalesce(col, default)` |
| Derive status | `F.when(cond, val).otherwise(other)` | `CASE WHEN cond THEN val ELSE other END` |
| Filter nulls | `.filter(F.col("pk").isNotNull())` | `WHERE pk IS NOT NULL` |

---

## Anti-Patterns (NEVER DO)

| Anti-Pattern | Why It Fails | Correct Pattern |
|---|---|---|
| `import dlt` | Deprecated | `from pyspark import pipelines as dp` |
| `%sql` magic | Not supported in SDP files | Use separate .sql file |
| `dbutils.widgets` | Not available in pipeline files | `spark.conf.get()` |
| `if run_mode == "full_refresh":` | Unnecessary | Framework handles both modes |
| `spark.read.table()` for silver | Loses incremental capability | `spark.readStream.table()` |
| `@dp.materialized_view()` for silver | NEVER use MV — breaks incremental | Use `@dp.table()` (Streaming Table) |
| Non-qualified table names | May not resolve cross-pipeline | Use `{catalog}.{schema}.{table}` |
| `spark.conf.set("pipelines.reset.allowed", ...)` | Not needed | Pipeline controls this |
