# DQX Alerts Skill

## Purpose
This skill covers the DQX Alert setup using the DQX validation output table. Alerts notify stakeholders when data quality checks fail.

---

## Critical Rules

| Rule | Description |
|---|---|
| Alert Source | DQX validation output table (`validation_type` + `status` columns) |
| Re-run Behavior | UPDATE existing alerts — NEVER create duplicates |
| Backing Query Location | Stored in the ingestion project folder (NOT user home directory) |
| Subject Format | `[{{ALERT_STATUS}}] {{ALERT_NAME}} \| DQX pipeline validation` |
| Body Content | Includes `{{QUERY_RESULT_TABLE}}` with failure details |
| Email Recipients | Support multiple recipients in list format |
| Parameterization | ALL values via dbutils.widgets — NEVER hard-coded |

---

## Notebook Structure

```python
# Cell 1: Parameters
# Cell 2: Alert Configuration
# Cell 3: Backing Query Creation/Update
# Cell 4: Alert Creation/Update
# Cell 5: Notification Setup
```

---

## Cell 1: Parameters (MANDATORY)

```python
# Databricks notebook source
# MAGIC %md
# MAGIC # DQX Alert Setup
# MAGIC ## Creates/Updates alerts based on DQX validation results

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import (
    AlertV2,
    AlertV2Condition,
    AlertV2Operand,
    AlertV2OperandColumn,
    AlertV2OperandValue,
    AlertV2Operator,
    AlertV2QuerySubscription,
    AlertV2NotificationDestination
)
import json

# Widget Parameters
dbutils.widgets.text("dqx_catalog", "", "DQX Results Catalog")
dbutils.widgets.text("dqx_schema", "", "DQX Results Schema")
dbutils.widgets.text("pipeline_name", "", "Pipeline Name")
dbutils.widgets.text("source_system", "", "Source System Name")
dbutils.widgets.dropdown("cloud_provider", "AWS", ["AWS", "Azure", "GCP"], "Cloud Provider")
dbutils.widgets.text("alert_recipients", "", "Alert Recipients (comma-separated emails)")
dbutils.widgets.text("project_folder", "", "Project Folder Path for Backing Query")
dbutils.widgets.text("warehouse_id", "", "SQL Warehouse ID")

# Retrieve parameters
dqx_catalog = dbutils.widgets.get("dqx_catalog")
dqx_schema = dbutils.widgets.get("dqx_schema")
pipeline_name = dbutils.widgets.get("pipeline_name")
source_system = dbutils.widgets.get("source_system")
cloud_provider = dbutils.widgets.get("cloud_provider")
alert_recipients = [r.strip() for r in dbutils.widgets.get("alert_recipients").split(",") if r.strip()]
project_folder = dbutils.widgets.get("project_folder")
warehouse_id = dbutils.widgets.get("warehouse_id")

# Validation
assert dqx_catalog, "ERROR: 'dqx_catalog' parameter is required"
assert dqx_schema, "ERROR: 'dqx_schema' parameter is required"
assert alert_recipients, "ERROR: 'alert_recipients' parameter is required"
assert project_folder, "ERROR: 'project_folder' parameter is required"

# Constants
DQX_TABLE = f"{dqx_catalog}.{dqx_schema}.dqx_validation_results"
ALERT_NAME = f"{source_system}_{pipeline_name}_dqx_alert"

w = WorkspaceClient()
```

---

## Cell 2: Backing Query

```python
# MAGIC %md
# MAGIC ## Backing Query for DQX Alert
# MAGIC Stored in project folder (NOT home directory)

# The backing query retrieves the latest DQX failures
BACKING_QUERY_SQL = f"""
SELECT
    validation_type,
    source_layer,
    target_layer,
    source_table,
    target_table,
    status,
    details,
    source_count,
    target_count,
    mismatch_count,
    run_mode,
    run_timestamp
FROM {DQX_TABLE}
WHERE pipeline_name = '{pipeline_name}'
  AND source_system = '{source_system}'
  AND run_timestamp = (
    SELECT MAX(run_timestamp)
    FROM {DQX_TABLE}
    WHERE pipeline_name = '{pipeline_name}'
      AND source_system = '{source_system}'
  )
  AND status = 'FAIL'
ORDER BY validation_type, source_layer, target_layer
"""

# Create or update the backing query in project folder
QUERY_NAME = f"{source_system}_dqx_alert_query"

# Search for existing query
existing_queries = w.queries.list()
query_id = None
for q in existing_queries:
    if q.name == QUERY_NAME:
        query_id = q.id
        break

if query_id:
    # UPDATE existing query
    w.queries.update(
        id=query_id,
        name=QUERY_NAME,
        query_text=BACKING_QUERY_SQL,
        warehouse_id=warehouse_id
    )
    print(f"Updated existing backing query: {QUERY_NAME} (ID: {query_id})")
else:
    # CREATE new query in project folder
    query = w.queries.create(
        name=QUERY_NAME,
        query_text=BACKING_QUERY_SQL,
        warehouse_id=warehouse_id,
        parent_path=project_folder  # Store in project folder, NOT home
    )
    query_id = query.id
    print(f"Created new backing query: {QUERY_NAME} (ID: {query_id})")
```

---

## Cell 3: Alert Creation/Update

```python
# MAGIC %md
# MAGIC ## Create or Update DQX Alert
# MAGIC Updates existing alert on re-run (never creates duplicates)

# Alert configuration
alert_config = {
    "display_name": ALERT_NAME,
    "query_id": query_id,
    "condition": AlertV2Condition(
        op=AlertV2Operator.GREATER_THAN,
        operand=AlertV2Operand(
            column=AlertV2OperandColumn(
                name="status",
                agg_type="COUNT"
            )
        ),
        threshold=AlertV2Operand(
            value=AlertV2OperandValue(double_value=0)
        )
    ),
    "custom_subject": f"[{{{{ALERT_STATUS}}}}] {ALERT_NAME} | DQX pipeline validation",
    "custom_body": f"""DQX Pipeline Validation Alert

Pipeline: {pipeline_name}
Source System: {source_system}

The following data quality checks have FAILED:

{{{{QUERY_RESULT_TABLE}}}}

Please investigate the failures and take corrective action.

DQX Results Table: {DQX_TABLE}
"""
}

# Search for existing alert
existing_alerts = w.alerts.list()
alert_id = None
for alert in existing_alerts:
    if alert.display_name == ALERT_NAME:
        alert_id = alert.id
        break

if alert_id:
    # UPDATE existing alert (never create duplicates)
    w.alerts.update(
        id=alert_id,
        display_name=alert_config["display_name"],
        query_id=alert_config["query_id"],
        condition=alert_config["condition"],
        custom_subject=alert_config["custom_subject"],
        custom_body=alert_config["custom_body"]
    )
    print(f"Updated existing alert: {ALERT_NAME} (ID: {alert_id})")
else:
    # CREATE new alert
    alert = w.alerts.create(
        display_name=alert_config["display_name"],
        query_id=alert_config["query_id"],
        condition=alert_config["condition"],
        custom_subject=alert_config["custom_subject"],
        custom_body=alert_config["custom_body"]
    )
    alert_id = alert.id
    print(f"Created new alert: {ALERT_NAME} (ID: {alert_id})")
```

---

## Cell 4: Notification/Subscription Setup

```python
# MAGIC %md
# MAGIC ## Email Notification Setup
# MAGIC Support multiple recipients in list format

# Add email subscriptions for all recipients
for email in alert_recipients:
    try:
        w.alerts.create_subscription(
            alert_id=alert_id,
            subscription=AlertV2QuerySubscription(
                destination=AlertV2NotificationDestination(
                    email=email
                )
            )
        )
        print(f"  Added subscriber: {email}")
    except Exception as e:
        # Subscription may already exist
        if "already exists" in str(e).lower():
            print(f"  Subscriber already exists: {email}")
        else:
            print(f"  Warning: Could not add {email}: {str(e)}")

print(f"\n{'='*60}")
print(f"DQX Alert Configuration Complete")
print(f"{'='*60}")
print(f"Alert Name: {ALERT_NAME}")
print(f"Alert ID: {alert_id}")
print(f"Backing Query: {QUERY_NAME} (ID: {query_id})")
print(f"Recipients: {alert_recipients}")
print(f"Subject: [{{ALERT_STATUS}}] {ALERT_NAME} | DQX pipeline validation")
print(f"Stored in: {project_folder}")
print(f"{'='*60}")
```

---

## Alert Template Reference

### Subject Line
```
[{{ALERT_STATUS}}] {{ALERT_NAME}} | DQX pipeline validation
```

### Body Template
```
DQX Pipeline Validation Alert

Pipeline: {pipeline_name}
Source System: {source_system}

The following data quality checks have FAILED:

{{QUERY_RESULT_TABLE}}

Please investigate the failures and take corrective action.

DQX Results Table: {dqx_catalog}.{dqx_schema}.dqx_validation_results
```

### Template Variables
| Variable | Description |
|---|---|
| `{{ALERT_STATUS}}` | Current alert status (Triggered/OK) |
| `{{ALERT_NAME}}` | Name of the alert |
| `{{QUERY_RESULT_TABLE}}` | Table of query results (failure details) |

---

## Key Behaviors

| Scenario | Behavior |
|---|---|
| First run | Creates new alert + backing query in project folder |
| Re-run | Updates existing alert (searches by name, never duplicates) |
| No failures | Alert condition not triggered (status = OK) |
| Failures found | Alert triggers, email sent to all recipients |
| New recipient added | Add to alert_recipients parameter, re-run notebook |
