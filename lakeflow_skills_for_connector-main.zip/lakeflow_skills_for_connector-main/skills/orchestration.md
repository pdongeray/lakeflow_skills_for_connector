# Orchestration Skill

## Purpose
This skill covers Lakeflow Jobs orchestration for the complete pipeline: Source/Bronze SDP Pipeline → Silver SDP Pipeline → Gold SDP Pipeline → DQX Validation → DQX Alerts. It handles dependency chaining, full refresh vs incremental mode, and serverless compute.

---

## Critical Rules

| Rule | Description |
|---|---|
| Dependencies | If ANY task fails, downstream tasks DO NOT trigger |
| First Run | Full Refresh mode |
| Subsequent Runs | Incremental mode |
| Run Mode | `run_mode` parameter controls Full Refresh vs Incremental |
| Compute | Serverless for ALL tasks |
| Cloud Provider | AWS, Azure, or GCP (parameterized via `cloud_provider`) |
| Task Order | SDP Pipeline → DQX Validation → DQX Alerts |

---

## run_mode Behavior Per Layer

| Layer | run_mode = full_refresh | run_mode = incremental | Watermark/Checkpoint |
|---|---|---|---|
| Source (Lakeflow Connect) | Re-snapshot entire source table | Resume from last CDC position / watermark column | CDC log position (LSN/SCN/binlog) or cursor_column (MOD_DT) |
| Bronze (SDP) | Drop + recreate streaming tables | Resume from last streaming checkpoint | Streaming table auto-checkpoint (per-table offset) |
| Silver (SDP) | Drop + recreate streaming tables | Resume from last streaming checkpoint | Streaming table auto-checkpoint (per-table offset) |
| Gold (SDP) | Drop + recreate streaming tables | Resume from last streaming checkpoint | Streaming table auto-checkpoint (per-table offset) |
| DQX Validation | Validate FULL dataset (all records) | Validate only records AFTER last_dqx_run_timestamp | last_dqx_run_timestamp stored in DQX results table |
| DQX Alerts | Query ALL FAIL results | Query FAIL results since last alert run | Alert run timestamp |

### Key Behaviors:
- **full_refresh**: `pipelines.reset.allowed = true` — ALL streaming tables dropped and rebuilt from scratch
- **incremental**: `pipelines.reset.allowed = false` — streaming tables resume from their last checkpoint offset
- **DQX results table is NEVER truncated** — survives both full_refresh and incremental runs
- **Watermark persistence**: Each layer's checkpoint is managed automatically by the SDP pipeline runtime

---

## Job Configuration

### Job Structure

```json
{
  "name": "{source_system}_ingestion_orchestration",
  "parameters": [
    {
      "name": "run_mode",
      "default": "incremental",
      "description": "Pipeline run_mode: full_refresh or incremental"
    }
  ],
  "tasks": [
    {
      "task_key": "bronze_pipeline",
      "description": "Run Bronze CDC ingestion SDP pipeline"
    },
    {
      "task_key": "silver_pipeline",
      "depends_on": ["bronze_pipeline"],
      "description": "Run Silver transformation SDP pipeline"
    },
    {
      "task_key": "gold_pipeline",
      "depends_on": ["silver_pipeline"],
      "description": "Run Gold aggregation SDP pipeline"
    },
    {
      "task_key": "dqx_cdc_vs_bronze",
      "depends_on": ["bronze_pipeline"],
      "description": "DQX validation: CDC vs Bronze"
    },
    {
      "task_key": "dqx_bronze_vs_silver",
      "depends_on": ["silver_pipeline", "dqx_cdc_vs_bronze"],
      "description": "DQX validation: Bronze vs Silver"
    },
    {
      "task_key": "dqx_silver_vs_gold",
      "depends_on": ["gold_pipeline", "dqx_bronze_vs_silver"],
      "description": "DQX validation: Silver vs Gold"
    },
    {
      "task_key": "dqx_alerts",
      "depends_on": ["dqx_silver_vs_gold"],
      "description": "DQX alert notification"
    }
  ]
}
```

---

## Task Dependency Diagram

```
                    [bronze_pipeline]
                    /              \\
                   /                \\
        [silver_pipeline]    [dqx_cdc_vs_bronze]
           /        \\                |
          /          \\               |
  [gold_pipeline]  [dqx_bronze_vs_silver]
         \\              /
          \\            /
       [dqx_silver_vs_gold]
               |
         [dqx_alerts]
```

---

## Python SDK Job Creation

```python
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import (
    Task, NotebookTask, PipelineTask,
    TaskDependency, JobCluster, JobParameter,
    Source, RunIf
)

w = WorkspaceClient()

# Parameters
source_system = dbutils.widgets.get("source_system")
pipeline_name = dbutils.widgets.get("pipeline_name")
project_folder = dbutils.widgets.get("project_folder")

# SDP Pipeline IDs (created separately)
bronze_pipeline_id = dbutils.widgets.get("bronze_pipeline_id")
silver_pipeline_id = dbutils.widgets.get("silver_pipeline_id")
gold_pipeline_id = dbutils.widgets.get("gold_pipeline_id")

# Notebook paths
dqx_notebook_path = f"{project_folder}/{source_system}_dqx_validation"
alert_notebook_path = f"{project_folder}/{source_system}_dqx_alerts"

# Common notebook parameters (passed from job-level run_mode)
common_params = {
    "catalog": "{{job.parameters.catalog}}",
    "schema": "{{job.parameters.schema}}",
    "cdc_catalog": "{{job.parameters.cdc_catalog}}",
    "cdc_schema": "{{job.parameters.cdc_schema}}",
    "pipeline_name": pipeline_name,
    "source_system": source_system,
    "run_mode": "{{job.parameters.run_mode}}",
    "cloud_provider": "{{job.parameters.cloud_provider}}"
}

# Task definitions
tasks = [
    # Task 1: Bronze SDP Pipeline
    Task(
        task_key="bronze_pipeline",
        description="Run Bronze CDC ingestion pipeline",
        pipeline_task=PipelineTask(
            pipeline_id=bronze_pipeline_id,
            full_refresh="{{job.parameters.run_mode == 'full_refresh'}}"
        ),
        run_if=RunIf.ALL_SUCCESS
    ),
    
    # Task 2: Silver SDP Pipeline (depends on Bronze)
    Task(
        task_key="silver_pipeline",
        description="Run Silver transformation pipeline",
        depends_on=[TaskDependency(task_key="bronze_pipeline")],
        pipeline_task=PipelineTask(
            pipeline_id=silver_pipeline_id,
            full_refresh="{{job.parameters.run_mode == 'full_refresh'}}"
        ),
        run_if=RunIf.ALL_SUCCESS
    ),
    
    # Task 3: Gold SDP Pipeline (depends on Silver)
    Task(
        task_key="gold_pipeline",
        description="Run Gold aggregation pipeline",
        depends_on=[TaskDependency(task_key="silver_pipeline")],
        pipeline_task=PipelineTask(
            pipeline_id=gold_pipeline_id,
            full_refresh="{{job.parameters.run_mode == 'full_refresh'}}"
        ),
        run_if=RunIf.ALL_SUCCESS
    ),
    
    # Task 4: DQX CDC vs Bronze (depends on Bronze)
    Task(
        task_key="dqx_cdc_vs_bronze",
        description="DQX validation: CDC vs Bronze",
        depends_on=[TaskDependency(task_key="bronze_pipeline")],
        notebook_task=NotebookTask(
            notebook_path=dqx_notebook_path,
            base_parameters={
                **common_params,
                "validation_scope": "cdc_vs_bronze"
            },
            source=Source.WORKSPACE
        ),
        run_if=RunIf.ALL_SUCCESS
    ),
    
    # Task 5: DQX Bronze vs Silver (depends on Silver + previous DQX)
    Task(
        task_key="dqx_bronze_vs_silver",
        description="DQX validation: Bronze vs Silver",
        depends_on=[
            TaskDependency(task_key="silver_pipeline"),
            TaskDependency(task_key="dqx_cdc_vs_bronze")
        ],
        notebook_task=NotebookTask(
            notebook_path=dqx_notebook_path,
            base_parameters={
                **common_params,
                "validation_scope": "bronze_vs_silver"
            },
            source=Source.WORKSPACE
        ),
        run_if=RunIf.ALL_SUCCESS
    ),
    
    # Task 6: DQX Silver vs Gold (depends on Gold + previous DQX)
    Task(
        task_key="dqx_silver_vs_gold",
        description="DQX validation: Silver vs Gold",
        depends_on=[
            TaskDependency(task_key="gold_pipeline"),
            TaskDependency(task_key="dqx_bronze_vs_silver")
        ],
        notebook_task=NotebookTask(
            notebook_path=dqx_notebook_path,
            base_parameters={
                **common_params,
                "validation_scope": "silver_vs_gold"
            },
            source=Source.WORKSPACE
        ),
        run_if=RunIf.ALL_SUCCESS
    ),
    
    # Task 7: DQX Alerts (depends on all DQX tasks)
    Task(
        task_key="dqx_alerts",
        description="Send DQX validation alerts",
        depends_on=[TaskDependency(task_key="dqx_silver_vs_gold")],
        notebook_task=NotebookTask(
            notebook_path=alert_notebook_path,
            base_parameters=common_params,
            source=Source.WORKSPACE
        ),
        run_if=RunIf.ALL_SUCCESS
    )
]

# Job-level parameters — ALL configurable values exposed for workspace portability
job_parameters = [
    JobParameter(name="run_mode", default="incremental"),
    JobParameter(name="bronze_catalog", default=""),
    JobParameter(name="bronze_schema", default=""),
    JobParameter(name="silver_catalog", default=""),
    JobParameter(name="silver_schema", default=""),
    JobParameter(name="gold_catalog", default=""),
    JobParameter(name="gold_schema", default=""),
    JobParameter(name="dqx_catalog", default=""),
    JobParameter(name="dqx_schema", default=""),
    JobParameter(name="connection_name", default=""),
    JobParameter(name="source_database", default=""),
    JobParameter(name="source_schema", default=""),
    JobParameter(name="cursor_column", default="updated_at"),
    JobParameter(name="source_system", default=""),
    JobParameter(name="pipeline_name", default=""),
    JobParameter(name="alert_recipients", default=""),
    JobParameter(name="project_folder", default=""),
    JobParameter(name="source_mapping_path", default=""),
    JobParameter(name="bronze_mapping_path", default=""),
    JobParameter(name="silver_sql_path", default=""),
    JobParameter(name="gold_sql_path", default="")
]

# Create or update job
JOB_NAME = f"{source_system}_ingestion_orchestration"

# Search for existing job
existing_jobs = w.jobs.list(name=JOB_NAME)
job_id = None
for job in existing_jobs:
    if job.settings.name == JOB_NAME:
        job_id = job.job_id
        break

if job_id:
    # Update existing job
    w.jobs.reset(
        job_id=job_id,
        new_settings={
            "name": JOB_NAME,
            "tasks": tasks,
            "parameters": job_parameters,
            "tags": {
                "source_system": source_system,
                "pipeline": pipeline_name,
                "team": "data-engineering"
            }
        }
    )
    print(f"Updated existing job: {JOB_NAME} (ID: {job_id})")
else:
    # Create new job
    job = w.jobs.create(
        name=JOB_NAME,
        tasks=tasks,
        parameters=job_parameters,
        tags={
            "source_system": source_system,
            "pipeline": pipeline_name,
            "team": "data-engineering"
        }
    )
    job_id = job.job_id
    print(f"Created new job: {JOB_NAME} (ID: {job_id})")
```

---

## Run Mode Logic

### First Run (Full Refresh)
```bash
# Run with full_refresh mode
databricks jobs run-now --job-id {job_id} \
  --params '{"run_mode": "full_refresh"}'
```

### Subsequent Runs (Incremental)
```bash
# Run with incremental mode (default)
databricks jobs run-now --job-id {job_id} \
  --params '{"run_mode": "incremental"}'
```

### Pipeline Full Refresh Behavior
- `full_refresh` mode: SDP pipelines run with `full_refresh=True`
  - All streaming tables are fully recomputed
  - DQX validation runs on full dataset
  - DQX results table is NOT truncated (only new results appended)
- `incremental` mode: SDP pipelines process only new/changed data
  - Streaming tables pick up from last checkpoint
  - DQX validation filters to records after last run timestamp

### run_mode Behavior Across ALL Layers

| Layer | run_mode = full_refresh | run_mode = incremental |
|---|---|---|
| **Bronze** (Lakeflow Connect) | Full snapshot from source (all records) | Only new/changed records since last watermark |
| **Silver** (SDP Streaming Table) | Truncate + replay ALL from bronze | Process ONLY new bronze records from checkpoint |
| **Gold** (SDP Streaming Table) | Truncate + replay ALL from silver | Process ONLY new silver records from checkpoint |
| **DQX** | Validate complete dataset | Validate current table state |

### Scheduling Pattern

| Scenario | run_mode | Schedule | Notes |
|---|---|---|---|
| **First Run** | `full_refresh` | Manual trigger | Loads everything from source |
| **Subsequent Runs** | `incremental` | Cron (daily/hourly/5-min) | Only new data at ALL layers |
| **Data Recovery** | `full_refresh` | Manual trigger | Rebuilds everything from scratch |

**Key**: ALL layers use Streaming Tables — `full_refresh` rebuilds everything; `incremental` processes only new data. No code changes needed between modes.

---

## Failure Handling

```python
# All tasks use RunIf.ALL_SUCCESS
# This ensures:
# 1. If bronze_pipeline FAILS:
#    - silver_pipeline does NOT run
#    - gold_pipeline does NOT run
#    - dqx_cdc_vs_bronze does NOT run
#    - All downstream tasks skip
# 2. If dqx_cdc_vs_bronze FAILS:
#    - dqx_bronze_vs_silver does NOT run
#    - dqx_silver_vs_gold does NOT run
#    - dqx_alerts does NOT run
# 3. Job sends failure notification via email_notifications
```

### Email Notifications on Job Failure

```python
from databricks.sdk.service.jobs import JobEmailNotifications

# Add email notifications to job
w.jobs.reset(
    job_id=job_id,
    new_settings={
        "name": JOB_NAME,
        "tasks": tasks,
        "parameters": job_parameters,
        "email_notifications": JobEmailNotifications(
            on_failure=[r for r in alert_recipients],
            on_success=[],
            no_alert_for_skipped_runs=False
        )
    }
)
```

---

## Schedule Configuration

```python
from databricks.sdk.service.jobs import CronSchedule

# Add schedule (optional)
schedule = CronSchedule(
    quartz_cron_expression="0 0 6 * * ?",  # Daily at 6 AM
    timezone_id="UTC"
)

w.jobs.reset(
    job_id=job_id,
    new_settings={
        "name": JOB_NAME,
        "tasks": tasks,
        "parameters": job_parameters,
        "schedule": schedule
    }
)
```

---

## Compute Configuration

All tasks run on Serverless:

```python
# For notebook tasks: Serverless is the default when no cluster is specified
# For pipeline tasks: Pipeline compute settings apply (configured at pipeline level)

# Explicit serverless environment for notebook tasks:
from databricks.sdk.service.jobs import TaskEnvironment

Task(
    task_key="dqx_validation",
    environment_key="serverless",  # Uses serverless compute
    notebook_task=NotebookTask(
        notebook_path=dqx_notebook_path,
        base_parameters=common_params,
        source=Source.WORKSPACE
    )
)
```

---

## Key Orchestration Patterns

| Pattern | Description |
|---|---|
| Sequential | Bronze → Silver → Gold (strict order) |
| Parallel with Join | DQX runs parallel to next layer, joins at alert |
| Fan-out | One pipeline feeds multiple DQX checks |
| Conditional | run_mode parameter controls full_refresh vs incremental |
| Retry | Failed tasks can be retried without re-running successful ones |
| Idempotent | Both modes safe to re-run (append DQX, checkpoint streaming) |
