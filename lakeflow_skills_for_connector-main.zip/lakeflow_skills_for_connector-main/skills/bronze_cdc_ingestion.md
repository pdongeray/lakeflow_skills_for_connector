# Bronze Ingestion Skill

## Purpose
This skill covers Bronze Layer ingestion for both **batch** (full_refresh) and **streaming** (incremental/CDC) modes. It supports two architecture patterns:

1. **Lakeflow Connect Managed Ingestion** — a separate pipeline with `ingestion_definition` (no code required)
2. **SDP Transformation Pipeline** — reads from ingestion output or other sources using Python/SQL

---

## CRITICAL RULES

1. **Lakeflow Connect uses `ingestion_definition`, NOT `libraries` or SQL DDL**
   - There is NO `CREATE TABLE ... FROM CONNECTION` syntax for Lakeflow Connect
   - Connection references (`connection_name.schema.table`) only resolve with a Foreign Catalog
   - Managed ingestion pipelines have NO code files — only JSON configuration

2. **SDP pipeline API**: `from pyspark import pipelines as dp` (NOT `import dlt`)
   - `@dp.table()` for Streaming Tables (ALL layers: Silver + Gold)
   - `dp.create_streaming_table()` + `dp.apply_changes()` for CDC
   - NEVER use `@dp.materialized_view()` — breaks incremental mode

3. **No `%sql` magic commands** in SDP pipeline files — causes `NO_TABLES_IN_PIPELINE` errors
   - Use separate `.sql` files for SQL definitions
   - Use separate `.py` files for Python definitions

4. **run_mode handling**:
   - `CREATE OR REFRESH STREAMING TABLE` + `STREAM()` handles BOTH modes natively
   - full_refresh = truncate + replay all; incremental = resume from checkpoint
   - Pipeline framework controls refresh behavior — NO code-level conditionals needed

5. **ALL layers (Bronze, Silver, Gold) use Streaming Tables** — NEVER Materialized Views
   - This ensures true incremental processing across all layers
   - full_refresh = rebuild everything; incremental = process only new data

---

## Architecture Pattern: Two-Pipeline Design

```
┌──────────────────────────────────────────────────────────┐
│  Pipeline 1: Lakeflow Connect Managed Ingestion          │
│  (pipeline_type: ingestion_definition)                   │
│                                                          │
│  {Source System} ──► {bronze_catalog}.{bronze_schema}.*   │
│  (N source tables → N bronze streaming tables)            │
└──────────────────────────────┬───────────────────────────┘
                               │
                               ▼
┌──────────────────────────────────────────────────────────┐
│  Pipeline 2: SDP Transformation Pipeline                 │
│  (pipeline_type: WORKSPACE, libraries: [files])          │
│                                                          │
│  Bronze ──► Silver (Streaming Tables)                    │
│  Silver ──► Gold (Streaming Tables)                      │
└──────────────────────────────────────────────────────────┘
```

---

## Pipeline 1: Lakeflow Connect Managed Ingestion

### Creating the Ingestion Pipeline (CLI/SDK)

Lakeflow Connect ingestion pipelines are created via API — NOT via SQL or Python code.

```bash
# CLI approach
databricks pipelines create --json '{
  "name": "{source_system}_lakeflow_ingestion",
  "ingestion_definition": {
    "connection_name": "{connection_name}",
    "objects": [
      {
        "table": {
          "source_schema": "{source_schema}",
          "source_table": "{table_name}",
          "destination_catalog": "{bronze_catalog}",
          "destination_schema": "{bronze_schema}"
        }
      }
    ]
  },
  "serverless": true,
  "catalog": "{bronze_catalog}",
  "channel": "PREVIEW"
}'
```

### Python SDK approach

```python
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.pipelines import (
    PipelineSpec, IngestionConfig, TableSpec, ManagedIngestionPipelineDefinition
)

w = WorkspaceClient()

# Populate tables list from source mapping document or user input
tables = ["table_1", "table_2", "table_3", ...]  # Replace with actual source tables

objects = [
    {"table": {
        "source_catalog": source_database,  # Required for PostgreSQL (database name)
        "source_schema": source_schema,     # e.g., "public", "dbo", "hr"
        "source_table": t,
        "destination_catalog": bronze_catalog,
        "destination_schema": bronze_schema
    }}
    for t in tables
]

pipeline = w.pipelines.create(
    name=f"{source_system}_lakeflow_ingestion",
    ingestion_definition={
        "connection_name": connection_name,
        "objects": objects
    },
    serverless=True,
    catalog=bronze_catalog,
    channel="PREVIEW"
)
print(f"Created ingestion pipeline: {pipeline.pipeline_id}")
```

### Ingestion Pipeline Behavior (Batch + Streaming)

| Mode | Behavior | Use Case |
|------|----------|----------|
| **Incremental** (streaming) | Uses watermark/cursor column to fetch only new/changed rows | Scheduled micro-batch, near-real-time freshness |
| **Full Refresh** (batch) | Re-snapshots entire source table; truncate + reload | Initial load, data recovery, nightly full sync |

Both modes are handled automatically by the Lakeflow Connect framework. No code changes needed.
The SAME ingestion pipeline supports both batch and streaming customers — only the trigger schedule differs.

### Ingestion Method vs Processing Mode

| Ingestion Method | Batch (full_refresh) | Streaming (incremental) |
|---|---|---|
| **Query-based** (cursor column) | Full snapshot of source | Reads rows where cursor > last watermark |
| **CDC-based** (gateway) | Full snapshot of source | Reads change events from last LSN/SCN/position |

### Running the Ingestion Pipeline

```bash
# Start an update (incremental by default)
databricks pipelines start-update <pipeline-id>

# Full refresh
databricks pipelines start-update <pipeline-id> --full-refresh
```

---

## Pipeline 2: SDP Transformation Pipeline (Silver + Gold)

### Silver Layer — Streaming Tables (Python)

Silver tables read from ingestion output using `spark.readStream.table()` for streaming mode.
Works for BOTH incremental and full_refresh — the pipeline framework handles the mode.

```python
from pyspark import pipelines as dp
from pyspark.sql import functions as F

# Silver tables read from bronze (ingestion output)
# Use fully qualified names since bronze is in a different pipeline

BRONZE_CATALOG = spark.conf.get("bronze_catalog")
BRONZE_SCHEMA = spark.conf.get("bronze_schema")

# Pattern: One @dp.table() per source table
# Replace {table_name}, {pk_col}, and transformations with actual values

@dp.table(
    name="silver_{table_name}",
    comment="Cleansed {table_name} data",
    cluster_by_auto=True,
    table_properties={"quality": "silver"}
)
def silver_{table_name}():
    return (
        spark.readStream.table(f"{BRONZE_CATALOG}.{BRONZE_SCHEMA}.{table_name}")
        # Apply domain-specific transformations from mapping document
        .filter(F.col("{pk_col}").isNotNull())
    )
```

### Silver Layer — Streaming Tables (SQL)

```sql
-- Silver layer SQL file (standalone .sql file, NOT %sql magic)
-- Works for BOTH incremental and full_refresh modes

-- Pattern: One STREAMING TABLE per source table
-- Replace {table_name}, {pk_col}, and column list with actual values

CREATE OR REFRESH STREAMING TABLE silver_{table_name}
CLUSTER BY AUTO
TBLPROPERTIES ('quality' = 'silver')
AS SELECT
  {pk_col},
  -- Apply transformations from mapping document
  *  -- Replace with explicit column list
FROM STREAM(${bronze_catalog}.${bronze_schema}.{table_name})
WHERE {pk_col} IS NOT NULL;
```

### Gold Layer — Streaming Tables (SQL) — NEVER Materialized Views

ALL Gold tables use Streaming Tables with STREAM() wrapper.
full_refresh = rebuild all; incremental = process only new silver records.

```sql
-- Gold layer SQL file (standalone .sql file)
-- Replace {entity}, table names, join keys, and metrics with actual values

CREATE OR REFRESH STREAMING TABLE gold_{entity}_summary
CLUSTER BY AUTO
TBLPROPERTIES ('quality' = 'gold')
AS SELECT
  e.{entity_pk},
  e.{entity_name_col},
  COUNT(DISTINCT t.{txn_pk}) AS total_transactions,
  SUM(t.{amount_col}) AS total_amount,
  MIN(t.{date_col}) AS first_date,
  MAX(t.{date_col}) AS last_date
FROM STREAM(${silver_catalog}.${silver_schema}.silver_{entity_table}) e
JOIN STREAM(${silver_catalog}.${silver_schema}.silver_{txn_table}) t
  ON e.{entity_pk} = t.{entity_fk}
GROUP BY e.{entity_pk}, e.{entity_name_col};
```

### Gold Layer — Streaming Tables (Python)

```python
# Pattern: Multi-table join gold aggregation using Streaming Table
# Replace {entity}, table names, join keys, and metrics with actual values

@dp.table(
    name="gold_{entity}_summary",
    comment="{Entity} summary metrics",
    cluster_by_auto=True,
    table_properties={"quality": "gold"}
)
def gold_{entity}_summary():
    entity = spark.readStream.table(f"{SILVER_CATALOG}.{SILVER_SCHEMA}.silver_{entity_table}")
    transactions = spark.readStream.table(f"{SILVER_CATALOG}.{SILVER_SCHEMA}.silver_{txn_table}")

    return (
        entity.join(transactions, "{join_key}")
        .groupBy("{entity_pk}", "{entity_name_col}")
        .agg(
            F.countDistinct("{txn_pk}").alias("total_transactions"),
            F.sum("{amount_col}").alias("total_amount"),
            F.min("{date_col}").alias("first_date"),
            F.max("{date_col}").alias("last_date")
        )
    )
```

---

## run_mode Behavior Across All Layers

| Layer | Table Type | Read Method | full_refresh | incremental |
|-------|-----------|-------------|------------|----------------|
| Bronze (Ingestion) | Streaming Table | Lakeflow Connect (managed) | Full snapshot from source | Only new/changed records (watermark) |
| Silver | Streaming Table | `spark.readStream.table()` / `STREAM()` | Truncate + replay ALL bronze | Only new bronze records (checkpoint) |
| Gold | Streaming Table | `spark.readStream.table()` / `STREAM()` | Truncate + replay ALL silver | Only new silver records (checkpoint) |

### Key Principles

1. **ALL layers use Streaming Tables** — NEVER Materialized Views
2. **`full_refresh`** = load everything from external sources, rebuild all layers from scratch
3. **`incremental`** = load only new/changed data, process delta at each layer
4. **No conditional code** needed for run_mode — the pipeline framework handles everything
5. **Lakeflow Connect** is triggered-only (not continuous) — schedule via Jobs
6. **Same code** works for both modes — `full_refresh` flag at runtime controls behavior

---

## Pipeline Configuration (SDP Transformation)

```yaml
# Pipeline settings for the transformation pipeline
name: "{source_system}_sdp_pipeline"
catalog: "{silver_catalog}"
schema: "{silver_schema}"
serverless: true
channel: "PREVIEW"
configuration:
  bronze_catalog: "{bronze_catalog}"
  bronze_schema: "{bronze_schema}"
  silver_catalog: "{silver_catalog}"
  silver_schema: "{silver_schema}"
  gold_catalog: "{gold_catalog}"
  gold_schema: "{gold_schema}"
  source_system: "{source_system}"
  run_mode: "incremental"
libraries:
  - file:
      path: "{pipeline_root}/transformations/silver_transformations.py"
  - file:
      path: "{pipeline_root}/transformations/gold_aggregations.sql"
```

---

## Anti-Patterns (NEVER DO)

| Anti-Pattern | Why It Fails | Correct Pattern |
|---|---|---|
| `%sql` magic in Python SDP files | Not supported; causes NO_TABLES_IN_PIPELINE | Use separate .sql files |
| `import dlt` | Deprecated API | `from pyspark import pipelines as dp` |
| `FROM connection_name.schema.table` without Foreign Catalog | TABLE_OR_VIEW_NOT_FOUND | Use Lakeflow Connect `ingestion_definition` |
| `CREATE TABLE ... FROM CONNECTION` | That's Lakehouse Federation, not Lakeflow Connect | Use `ingestion_definition` JSON |
| `@dp.materialized_view()` for Gold | Breaks incremental mode | Use `@dp.table()` + `spark.readStream` |
| `spark.readStream.table("connection.schema.table")` | Connection refs don't work in Python | Use Lakeflow Connect managed ingestion |
| `continuous: true` for Lakeflow Connect | Not supported | Use triggered mode + Jobs schedule |
| `libraries` block in ingestion pipeline | Wrong pipeline type | Use `ingestion_definition` |
| `if run_mode == "full_refresh":` conditionals | Unnecessary complexity | Pipeline framework handles both modes |

---

## CDC Pattern (for databases with change tracking)

When the source supports CDC (SQL Server, PostgreSQL CDC, MySQL CDC):

### Ingestion Pipeline (Lakeflow Connect with Gateway)

```python
# SDK approach for CDC-based ingestion
pipeline = w.pipelines.create(
    name=f"{source_system}_cdc_ingestion",
    ingestion_definition={
        "connection_name": connection_name,
        "objects": [
            {"table": {
                "source_schema": source_schema,
                "source_table": table_name,
                "destination_catalog": bronze_catalog,
                "destination_schema": bronze_schema
            }}
            for table_name in source_tables
        ]
    },
    serverless=True,
    catalog=bronze_catalog,
    channel="PREVIEW"
)
```

### SDP Bronze Layer (CDC Apply Changes)

When processing CDC events in an SDP pipeline:

```python
from pyspark import pipelines as dp
from pyspark.sql import functions as F

# Create target streaming table
# Pattern: CDC apply_changes for SCD Type 2
# Replace {table_name}, {pk_col}, and {sequence_col} with actual values

dp.create_streaming_table(
    name="bronze_{table_name}",
    comment="Bronze SCD2 table for {table_name}",
    cluster_by_auto=True,
    table_properties={
        "quality": "bronze",
        "delta.enableChangeDataFeed": "true"
    }
)

# Apply CDC changes with SCD Type 2
dp.apply_changes(
    target="bronze_{table_name}",
    source="cdc_raw_{table_name}",
    keys=["{pk_col}"],
    sequence_by="{sequence_col}",  # e.g., updated_at, _commit_timestamp
    apply_as_deletes=F.expr("_operation_type = 'DELETE'"),
    stored_as_scd_type=2
)
```
