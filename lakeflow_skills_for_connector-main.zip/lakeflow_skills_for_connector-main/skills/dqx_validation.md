# DQX Validation Skill

## Purpose
This skill covers the Data Quality (DQX) validation framework that runs in BATCH mode between pipeline layers. It validates data integrity across Bronze, Silver, and Gold layers. Supports both **batch** (full_refresh) and **streaming** (incremental) pipeline outputs.

---

## Critical Rules

| Rule | Description |
|---|---|
| Mode | BATCH ONLY — queries materialized tables, NOT streams |
| Status Values | PASS or FAIL only (no other values permitted) |
| Results Table | NEVER truncated — not on Full Refresh, not on Incremental |
| Column Exclusions | Exclude ALL audit columns AND all `_DNAP_*` columns from validations |
| Clustering | CLUSTER BY AUTO on ALL DQX output tables |
| Scope | Record count & data validation on FULL dataset, not specific columns |
| Incremental Mode | Filter checks to records after last DQX run timestamp |
| Storage | Standard Delta table with INSERT — NOT a materialized view |
| Parameterization | ALL values via pipeline parameters (spark.conf.get) — NEVER hard-coded |
| API | Use `from pyspark import pipelines as dp` (NOT `import dlt`) |
| No Magic | No `%sql` magic commands — use spark.sql() for SQL in Python |

---

## Architecture Context

DQX validation runs AFTER both pipelines complete:

```
[Lakeflow Connect Ingestion] → [SDP Transformation] → [DQX Validation Notebook]
```

### DQX Works Identically for Batch AND Streaming Pipelines

DQX always runs in **BATCH mode** regardless of whether the upstream pipeline processed data in batch or streaming mode. It queries the CURRENT materialized state of tables.

| run_mode | DQX Behavior | What It Validates |
|---|---|---|
| **full_refresh** | Queries full tables | Complete dataset integrity after full rebuild |
| **incremental** | Queries full tables | Current state including new/changed records |

### What DQX Validates Per Mode

| Mode | Bronze Tables | Silver Tables | Gold Tables |
|------|--------------|---------------|-------------|
| **full_refresh** | Full snapshot counts | All transformed records | All aggregated records |
| **incremental** | Delta records (since last watermark) | New/changed records | Recomputed aggregations |

**Key**: DQX always runs in BATCH mode regardless of pipeline run_mode.
It reads the CURRENT state of tables (which reflect either full_refresh or incremental results).
The SAME DQX notebook works for batch customers, streaming customers, and hybrid customers.

---

## Notebook Structure

```python
# Cell 1: Parameters & Configuration
# Cell 2: DQX Results Table Setup (CREATE IF NOT EXISTS)
# Cell 3: Helper Functions
# Cell 4: Source vs Bronze Validations
# Cell 5: Bronze vs Silver Validations
# Cell 6: Silver vs Gold Validations
# Cell 7: Summary & Results
```

---

## Cell 1: Parameters

```python
from pyspark.sql import functions as F
from pyspark.sql.types import *
from datetime import datetime
import uuid

# Pipeline parameters (passed from Job or widget)
bronze_catalog = spark.conf.get("bronze_catalog", "")
bronze_schema = spark.conf.get("bronze_schema", "")
silver_catalog = spark.conf.get("silver_catalog", "")
silver_schema = spark.conf.get("silver_schema", "")
gold_catalog = spark.conf.get("gold_catalog", "")
gold_schema = spark.conf.get("gold_schema", "")
dqx_catalog = spark.conf.get("dqx_catalog", "")
dqx_schema = spark.conf.get("dqx_schema", "")
pipeline_name = spark.conf.get("pipeline_name", "")
source_system = spark.conf.get("source_system", "")
run_mode = spark.conf.get("run_mode", "incremental")
connection_name = spark.conf.get("connection_name", "")

# Validation run metadata
run_id = str(uuid.uuid4())
run_timestamp = datetime.now()

# Dynamically discover tables from bronze schema (no hardcoding)
source_tables = [
    row.tableName for row in 
    spark.sql(f"SHOW TABLES IN {bronze_catalog}.{bronze_schema}").collect()
    if not row.tableName.startswith("_")  # exclude system tables
]

# Primary key map — loaded from mapping document or passed as parameter
# Agent MUST populate this from the source/bronze mapping document at build time
# Example format: {"table_name": "pk_column_name", ...}
pk_map_json = spark.conf.get("pk_map", "{}")
import json
pk_map = json.loads(pk_map_json) if pk_map_json != "{}" else {}

# If pk_map not provided, infer from table schema (columns ending with _id that match table name)
if not pk_map:
    for table in source_tables:
        inferred_pk = f"{table.rstrip('s')}_id"  # naive: 'orders' -> 'order_id'
        try:
            cols = [c.name for c in spark.table(f"{bronze_catalog}.{bronze_schema}.{table}").schema]
            if inferred_pk in cols:
                pk_map[table] = inferred_pk
            elif f"{table}_id" in cols:
                pk_map[table] = f"{table}_id"
            else:
                # Use first column ending in '_id'
                id_cols = [c for c in cols if c.endswith("_id")]
                if id_cols:
                    pk_map[table] = id_cols[0]
        except:
            pass

# Columns to exclude from validation
EXCLUDE_COLUMNS = ["_rescued_data", "_ingestion_timestamp", "_source_system",
                   "_operation_type", "_sequence_num", "_event_timestamp"]
EXCLUDE_PREFIXES = ["_DNAP_", "__"]
```

---

## Cell 2: Results Table Setup

```python
# Create DQX results table if not exists (NEVER truncate)
spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {dqx_catalog}.{dqx_schema}.dqx_validation_results (
        validation_id STRING,
        pipeline_name STRING,
        source_system STRING,
        validation_type STRING,
        source_layer STRING,
        target_layer STRING,
        source_table STRING,
        target_table STRING,
        status STRING,
        details STRING,
        source_count BIGINT,
        target_count BIGINT,
        mismatch_count BIGINT,
        run_mode STRING,
        run_timestamp TIMESTAMP,
        CRE_DT TIMESTAMP
    )
    CLUSTER BY AUTO
    TBLPROPERTIES ('quality' = 'dqx')
""")
```

---

## Cell 3: Helper Functions

```python
def write_result(validation_type, source_layer, target_layer, 
                 source_table, target_table, status, details,
                 source_count=0, target_count=0, mismatch_count=0):
    """Write a single validation result to the DQX table."""
    result = spark.createDataFrame([{
        "validation_id": f"{run_id}_{validation_type}_{source_table}",
        "pipeline_name": pipeline_name,
        "source_system": source_system,
        "validation_type": validation_type,
        "source_layer": source_layer,
        "target_layer": target_layer,
        "source_table": source_table,
        "target_table": target_table,
        "status": status,
        "details": details,
        "source_count": source_count,
        "target_count": target_count,
        "mismatch_count": mismatch_count,
        "run_mode": run_mode,
        "run_timestamp": run_timestamp,
        "CRE_DT": run_timestamp
    }])
    result.write.mode("append").saveAsTable(
        f"{dqx_catalog}.{dqx_schema}.dqx_validation_results"
    )

def get_table_count(catalog, schema, table):
    """Get record count for a table."""
    try:
        return spark.table(f"{catalog}.{schema}.{table}").count()
    except Exception as e:
        return -1

def check_pk_uniqueness(catalog, schema, table, pk_column):
    """Check primary key uniqueness."""
    df = spark.table(f"{catalog}.{schema}.{table}")
    total = df.count()
    distinct = df.select(pk_column).distinct().count()
    return total == distinct, total, distinct

def check_not_null(catalog, schema, table, columns):
    """Check that specified columns have no nulls."""
    df = spark.table(f"{catalog}.{schema}.{table}")
    null_counts = {}
    for col in columns:
        null_count = df.filter(F.col(col).isNull()).count()
        if null_count > 0:
            null_counts[col] = null_count
    return len(null_counts) == 0, null_counts
```

---

## Cell 4: Source vs Bronze Validations

```python
# Validate Bronze tables (output of Lakeflow Connect ingestion)
# Works for BOTH full_refresh (all records) and incremental (delta records)

for table in source_tables:
    bronze_table = f"{bronze_catalog}.{bronze_schema}.{table}"
    
    # RECORD_COUNT — verify bronze table has data
    try:
        bronze_count = spark.table(bronze_table).count()
        status = "PASS" if bronze_count > 0 else "FAIL"
        write_result(
            "RECORD_COUNT", "source", "bronze",
            f"{connection_name}.{table}", table,
            status, f"Bronze count: {bronze_count}",
            source_count=0, target_count=bronze_count
        )
    except Exception as e:
        write_result(
            "RECORD_COUNT", "source", "bronze",
            f"{connection_name}.{table}", table,
            "FAIL", f"Error: {str(e)}"
        )
    
    # PK_UNIQUENESS — uses pk_map populated from mapping document or inferred
    if table in pk_map:
        is_unique, total, distinct = check_pk_uniqueness(
            bronze_catalog, bronze_schema, table, pk_map[table]
        )
        write_result(
            "PK_UNIQUENESS", "source", "bronze",
            table, table,
            "PASS" if is_unique else "FAIL",
            f"Total: {total}, Distinct PKs: {distinct}",
            source_count=total, target_count=distinct,
            mismatch_count=total - distinct
        )
```

---

## Cell 5: Bronze vs Silver Validations

```python
# Validate Silver transformations applied correctly
# Works for BOTH modes — reads current table state

for table in source_tables:
    bronze_fqn = f"{bronze_catalog}.{bronze_schema}.{table}"
    silver_fqn = f"{silver_catalog}.{silver_schema}.silver_{table}"
    
    # RECORD_COUNT
    bronze_count = get_table_count(bronze_catalog, bronze_schema, table)
    silver_count = get_table_count(silver_catalog, silver_schema, f"silver_{table}")
    
    # Silver may have fewer records (filtered nulls, deduplication)
    status = "PASS" if silver_count > 0 and silver_count <= bronze_count else "FAIL"
    write_result(
        "RECORD_COUNT", "bronze", "silver",
        table, f"silver_{table}",
        status, f"Bronze: {bronze_count}, Silver: {silver_count}",
        source_count=bronze_count, target_count=silver_count,
        mismatch_count=abs(bronze_count - silver_count)
    )
    
    # TRANSFORMATION_VALIDATION — verify transformations applied
    try:
        silver_df = spark.table(silver_fqn)
        # Check no null PKs in silver (should be filtered)
        pk_col = pk_map.get(table, f"{table[:-1]}_id")
        null_pks = silver_df.filter(F.col(pk_col).isNull()).count()
        status = "PASS" if null_pks == 0 else "FAIL"
        write_result(
            "TRANSFORMATION_VALIDATION", "bronze", "silver",
            table, f"silver_{table}",
            status, f"Null PKs in silver: {null_pks}",
            mismatch_count=null_pks
        )
    except Exception as e:
        write_result(
            "TRANSFORMATION_VALIDATION", "bronze", "silver",
            table, f"silver_{table}",
            "FAIL", f"Error: {str(e)}"
        )
```

---

## Cell 6: Silver vs Gold Validations

```python
# Validate Gold aggregations match Silver source data
# Gold tables are Streaming Tables — full_refresh rebuilds all; incremental processes new only

gold_tables = {
    "gold_customer_lifetime_value": ["silver_customers", "silver_orders", "silver_order_items"],
    "gold_product_performance": ["silver_products", "silver_order_items", "silver_reviews"],
    "gold_daily_sales_summary": ["silver_orders", "silver_order_items"],
    "gold_supplier_scorecard": ["silver_suppliers", "silver_products", "silver_order_items"],
    "gold_category_analytics": ["silver_categories", "silver_products", "silver_order_items"]
}

for gold_table, source_tables_list in gold_tables.items():
    gold_fqn = f"{gold_catalog}.{gold_schema}.{gold_table}"
    
    # RECORD_COUNT — gold should have data
    gold_count = get_table_count(gold_catalog, gold_schema, gold_table)
    status = "PASS" if gold_count > 0 else "FAIL"
    write_result(
        "RECORD_COUNT", "silver", "gold",
        ", ".join(source_tables_list), gold_table,
        status, f"Gold count: {gold_count}",
        target_count=gold_count
    )
    
    # DATA_VALIDATION — verify aggregation integrity
    try:
        gold_df = spark.table(gold_fqn)
        # Check no null values in key metrics
        null_check = gold_df.select(
            *[F.sum(F.when(F.col(c).isNull(), 1).otherwise(0)).alias(c)
              for c in gold_df.columns if c not in EXCLUDE_COLUMNS]
        ).collect()[0]
        
        null_cols = [c for c in gold_df.columns 
                     if c not in EXCLUDE_COLUMNS and null_check[c] > 0]
        status = "PASS" if len(null_cols) == 0 else "FAIL"
        write_result(
            "DATA_VALIDATION", "silver", "gold",
            ", ".join(source_tables_list), gold_table,
            status, f"Null columns in gold: {null_cols if null_cols else 'None'}",
            mismatch_count=len(null_cols)
        )
    except Exception as e:
        write_result(
            "DATA_VALIDATION", "silver", "gold",
            ", ".join(source_tables_list), gold_table,
            "FAIL", f"Error: {str(e)}"
        )
```

---

## Cell 7: Summary

```python
# Print validation summary
results_df = spark.table(f"{dqx_catalog}.{dqx_schema}.dqx_validation_results")
current_run = results_df.filter(F.col("validation_id").startswith(run_id))

total = current_run.count()
passed = current_run.filter(F.col("status") == "PASS").count()
failed = current_run.filter(F.col("status") == "FAIL").count()

print(f"DQX Validation Complete")
print(f"Run Mode: {run_mode}")
print(f"Total Checks: {total}")
print(f"Passed: {passed}")
print(f"Failed: {failed}")

if failed > 0:
    print("\nFailed Validations:")
    current_run.filter(F.col("status") == "FAIL").select(
        "validation_type", "source_table", "target_table", "details"
    ).show(truncate=False)
```

---

## Batch vs Streaming Considerations

| Aspect | Batch (full_refresh) | Streaming (incremental) |
|--------|---------------------|------------------------|
| Bronze counts | Full source snapshot | Only new/changed records |
| Silver counts | All transformed records | New records from checkpoint |
| Gold counts | Full aggregation (rebuilt from silver) | Incremental aggregation (new silver records only) |
| DQX scope | Full dataset | Full dataset (current state) |
| FRESHNESS check | Compare with source timestamp | Compare with last watermark |

**Important**: DQX always validates the CURRENT table state, regardless of how it was populated (batch or streaming). The `run_mode` parameter is recorded for audit purposes but doesn't change validation logic.
