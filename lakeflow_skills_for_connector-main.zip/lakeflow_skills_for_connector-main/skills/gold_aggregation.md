# Gold Aggregation Skill

## Purpose
This skill covers Gold Layer pipeline construction using Spark Declarative Pipelines (SDP). The Gold layer produces business-ready aggregations, KPIs, and metrics from Silver layer data. Supports both **batch** (full_refresh) and **streaming** (incremental) modes.

---

## CRITICAL: Gold Tables MUST Use Streaming Tables (NEVER Materialized Views)

**ALL Gold tables — including those with GROUP BY / aggregations — MUST be Streaming Tables.**

This ensures consistent incremental behavior across ALL layers:

| run_mode | Gold Behavior | What Gets Processed |
|---|---|---|
| **full_refresh** | Truncate gold tables + replay ALL silver records | Everything — complete rebuild of aggregations |
| **incremental** | Resume from checkpoint + process ONLY new silver records | Only new/changed data — aggregation state updated |

### Why Streaming Tables for Gold (not MVs)

| Reason | Explanation |
|--------|-------------|
| Incremental processing | MVs always recompute fully; STs resume from checkpoint |
| Consistent architecture | Same pattern (ST + readStream) across Bronze, Silver, Gold |
| run_mode controls ALL layers | `full_refresh` rebuilds everything; `incremental` processes delta |
| SDP handles stateful aggregations | Framework manages GROUP BY state internally for streaming tables |
| Lower latency in incremental mode | No full recompute — only new records processed |

---

## File Structure (Standalone .sql or .py file)

```
transformations/
└── gold_aggregations.sql    # SQL with CREATE OR REFRESH STREAMING TABLE + STREAM()
```

Or Python:
```
transformations/
└── gold_aggregations.py     # Python with @dp.table() + spark.readStream.table()
```

---

## Critical Rules

| Rule | Description |
|---|---|
| API | `from pyspark import pipelines as dp` (NOT `import dlt`) |
| Table Type | Streaming Table (`@dp.table()` or `CREATE OR REFRESH STREAMING TABLE`) — NEVER Materialized View |
| Read Method | `spark.readStream.table()` in Python; `STREAM()` wrapper in SQL |
| No Magic | No `%sql` magic — standalone `.sql` or `.py` file |
| Clustering | `cluster_by_auto=True` on ALL gold tables |
| Both Modes | full_refresh = rebuild all; incremental = process only new records from checkpoint |
| Source Reference | Fully qualified: `{silver_catalog}.{silver_schema}.{table}` |
| Parameters | `spark.conf.get()` in Python; `${param}` in SQL |
| Aggregations | GROUP BY IS supported in SDP Streaming Tables — framework manages stateful aggregation |

---

## run_mode Behavior for Gold

| run_mode | Gold Behavior | What Gets Processed |
|------|---|---|
| **full_refresh** | Truncate gold tables + replay ALL silver records | Complete rebuild of all aggregations from scratch |
| **incremental** | Resume from checkpoint + process only NEW silver records | Only new data — aggregation state updated incrementally |

**Key Insight**: Using Streaming Tables at Gold layer ensures TRUE incremental processing:
- **full_refresh**: Pipeline drops + rebuilds gold tables from complete silver dataset
- **incremental**: Pipeline picks up only new silver records and updates aggregation state
- **No code changes** between modes — the pipeline `full_refresh` flag controls behavior
- **Consistent across all layers**: Bronze, Silver, and Gold all use the same incremental pattern

---

## SQL Pattern (Primary — Recommended for Gold)

```sql
-- gold_aggregations.sql
-- All gold tables use CREATE OR REFRESH STREAMING TABLE with STREAM() wrapper
-- full_refresh = rebuild all; incremental = process only new silver records
-- Replace {entity}, {table}, {pk}, {fk}, {metric} with actual values from gold mapping doc

-- Pattern 1: Entity Lifetime/Summary (single entity aggregation)
-- Use for: customer lifetime value, account summary, entity performance
CREATE OR REFRESH STREAMING TABLE gold_{entity}_summary
CLUSTER BY AUTO
TBLPROPERTIES ('quality' = 'gold')
COMMENT '{Entity} summary with aggregated metrics'
AS SELECT
  e.{entity_pk},
  e.{entity_name_col},
  COUNT(DISTINCT t.{transaction_pk}) AS total_transactions,
  SUM(t.{amount_col}) AS total_amount,
  AVG(t.{amount_col}) AS avg_amount,
  MIN(t.{date_col}) AS first_activity_date,
  MAX(t.{date_col}) AS last_activity_date
FROM STREAM(${silver_catalog}.${silver_schema}.silver_{entity_table}) e
LEFT JOIN STREAM(${silver_catalog}.${silver_schema}.silver_{transaction_table}) t
  ON e.{entity_pk} = t.{entity_fk}
GROUP BY e.{entity_pk}, e.{entity_name_col};

-- Pattern 2: Time-Series Summary (daily/weekly/monthly aggregation)
-- Use for: daily sales, hourly metrics, monthly reports
CREATE OR REFRESH STREAMING TABLE gold_daily_{domain}_summary
CLUSTER BY AUTO
TBLPROPERTIES ('quality' = 'gold')
COMMENT 'Daily {domain} aggregation'
AS SELECT
  t.{date_col} AS report_date,
  COUNT(DISTINCT t.{transaction_pk}) AS total_transactions,
  COUNT(DISTINCT t.{entity_fk}) AS unique_entities,
  SUM(t.{quantity_col}) AS total_quantity,
  SUM(t.{amount_col}) AS total_amount,
  AVG(t.{amount_col}) AS avg_amount
FROM STREAM(${silver_catalog}.${silver_schema}.silver_{transaction_table}) t
GROUP BY t.{date_col};

-- Pattern 3: Multi-Table Join Aggregation (cross-entity metrics)
-- Use for: product performance, scorecard, category analytics
CREATE OR REFRESH STREAMING TABLE gold_{entity}_performance
CLUSTER BY AUTO
TBLPROPERTIES ('quality' = 'gold')
COMMENT '{Entity}-level performance metrics'
AS SELECT
  p.{entity_pk},
  p.{entity_name_col},
  p.{category_col},
  COUNT(DISTINCT d.{detail_pk}) AS total_records,
  SUM(d.{metric_col}) AS total_metric,
  AVG(f.{score_col}) AS avg_score
FROM STREAM(${silver_catalog}.${silver_schema}.silver_{entity_table}) p
LEFT JOIN STREAM(${silver_catalog}.${silver_schema}.silver_{detail_table}) d
  ON p.{entity_pk} = d.{entity_fk}
LEFT JOIN STREAM(${silver_catalog}.${silver_schema}.silver_{feedback_table}) f
  ON p.{entity_pk} = f.{entity_fk}
GROUP BY p.{entity_pk}, p.{entity_name_col}, p.{category_col};
```

---

## Python Pattern (Alternative)

```python
from pyspark import pipelines as dp
from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Pipeline parameters
SILVER_CATALOG = spark.conf.get("silver_catalog")
SILVER_SCHEMA = spark.conf.get("silver_schema")
SOURCE_SYSTEM = spark.conf.get("source_system")

# Pattern 1: Entity Summary Aggregation (Streaming Table + readStream)
# full_refresh = rebuild all; incremental = process only new records

@dp.table(
    name="gold_{entity}_summary",
    comment="{Entity} summary with aggregated metrics",
    cluster_by_auto=True,
    table_properties={"quality": "gold", "source_system": SOURCE_SYSTEM}
)
def gold_{entity}_summary():
    entity = spark.readStream.table(f"{SILVER_CATALOG}.{SILVER_SCHEMA}.silver_{entity_table}")
    transactions = spark.readStream.table(f"{SILVER_CATALOG}.{SILVER_SCHEMA}.silver_{txn_table}")
    
    return (
        entity
        .join(transactions, "{join_key}", "left")
        .groupBy("{entity_pk}", "{entity_name_col}")
        .agg(
            F.countDistinct("{txn_pk}").alias("total_transactions"),
            F.sum("{amount_col}").alias("total_amount"),
            F.avg("{amount_col}").alias("avg_amount"),
            F.min("{date_col}").alias("first_date"),
            F.max("{date_col}").alias("last_date")
        )
    )

# Pattern 2: Time-Series Aggregation (Streaming Table)
@dp.table(
    name="gold_daily_{domain}_summary",
    comment="Daily {domain} aggregation",
    cluster_by_auto=True,
    table_properties={"quality": "gold"}
)
def gold_daily_{domain}_summary():
    transactions = spark.readStream.table(f"{SILVER_CATALOG}.{SILVER_SCHEMA}.silver_{txn_table}")
    details = spark.readStream.table(f"{SILVER_CATALOG}.{SILVER_SCHEMA}.silver_{detail_table}")
    
    return (
        transactions.join(details, "{join_key}")
        .groupBy("{date_col}")
        .agg(
            F.countDistinct("{txn_pk}").alias("total_transactions"),
            F.countDistinct("{entity_fk}").alias("unique_entities"),
            F.sum("{quantity_col}").alias("total_quantity"),
            F.sum("{amount_col}").alias("total_amount")
        )
    )
```

---

## Window Functions (Allowed in Gold)

```python
# Pattern: Ranking and segmentation using window functions
# Replace {entity}, {metric_col}, and segment labels with domain-specific values

@dp.table(
    name="gold_{entity}_ranking",
    comment="{Entity} ranking by {metric}",
    cluster_by_auto=True,
    table_properties={"quality": "gold"}
)
def gold_{entity}_ranking():
    source = spark.readStream.table("gold_{entity}_summary")  # Same pipeline = short name OK
    
    window = Window.orderBy(F.desc("{metric_col}"))
    
    return (
        source
        .withColumn("rank", F.dense_rank().over(window))
        .withColumn("percentile", F.percent_rank().over(window))
        .withColumn("{entity}_segment", 
            F.when(F.col("percentile") <= 0.1, "Top Tier")
            .when(F.col("percentile") <= 0.3, "High")
            .when(F.col("percentile") <= 0.7, "Medium")
            .otherwise("Low")
        )
    )
```

---

## Enrichment/Denormalization Pattern (No GROUP BY)

```python
# Pattern: Stream-to-static join for dimension lookups (NO GROUP BY)
# full_refresh = replay all; incremental = only new fact records

@dp.table(
    name="gold_{entity}_enriched",
    comment="Enriched/denormalized {entity} for downstream consumption",
    cluster_by_auto=True,
    table_properties={"quality": "gold"}
)
def gold_{entity}_enriched():
    # Stream the main silver fact table
    fact = spark.readStream.table(f"{SILVER_CATALOG}.{SILVER_SCHEMA}.silver_{fact_table}")
    # Static read for dimension lookups (broadcast for small tables)
    dim = spark.read.table(f"{SILVER_CATALOG}.{SILVER_SCHEMA}.silver_{dim_table}")
    
    return (
        fact
        .join(F.broadcast(dim), "{join_key}", "left")
        .select(
            fact["{fact_pk}"],
            fact["{join_key}"],
            dim["{dim_col}"].alias("{alias}"),
        )
    )
```

```sql
-- SQL equivalent: Streaming gold enrichment (NO GROUP BY)
CREATE OR REFRESH STREAMING TABLE gold_{entity}_enriched
CLUSTER BY AUTO
TBLPROPERTIES ('quality' = 'gold')
AS SELECT
  f.{fact_pk},
  f.{join_key},
  d.{dim_col} AS {alias},
  f.*
FROM STREAM(${silver_catalog}.${silver_schema}.silver_{fact_table}) f
LEFT JOIN ${silver_catalog}.${silver_schema}.silver_{dim_table} d
  ON f.{join_key} = d.{join_key};
```

---

## Anti-Patterns (NEVER DO)

| Anti-Pattern | Why It Fails | Correct Pattern |
|---|---|---|
| `import dlt` | Deprecated | `from pyspark import pipelines as dp` |
| `@dp.materialized_view()` for gold | NEVER use MV — breaks incremental mode | `@dp.table()` (Streaming Table) |
| `spark.read.table()` for gold | Loses incremental capability | `spark.readStream.table()` |
| `CREATE OR REFRESH MATERIALIZED VIEW` | NEVER use MV at Gold layer | `CREATE OR REFRESH STREAMING TABLE` |
| Direct `SELECT FROM` without `STREAM()` | Breaks incremental mode | Always use `STREAM()` wrapper in SQL |
| `%sql` magic | Not supported in SDP files | Separate .sql file |
| `dbutils.widgets` | Not in pipeline files | `spark.conf.get()` |
| `if run_mode == ...` conditionals | Unnecessary | Framework handles both modes |
| `spark.conf.set("pipelines.reset.allowed")` | Not needed | Pipeline framework controls |
| Non-qualified table names for cross-pipeline | May not resolve | Use `{catalog}.{schema}.{table}` |
| Window functions in gold streaming tables | Supported in SDP framework | `@dp.table()` + `spark.readStream.table()` |

---

## run_mode Summary for Gold

| run_mode | Gold Behavior | What Happens |
|---|---|---|
| **full_refresh** | Truncate ALL gold tables + replay ALL silver records | Complete rebuild from scratch |
| **incremental** | Resume from checkpoint + process ONLY new silver records | Only new data processed |

**ALL gold tables (with or without GROUP BY):**
- Use `@dp.table()` + `spark.readStream.table()` (Python)
- Use `CREATE OR REFRESH STREAMING TABLE` + `STREAM()` (SQL)
- `full_refresh`: Framework drops + rebuilds from complete silver dataset
- `incremental`: Framework picks up only new silver records, updates state
- Same code handles both modes — `full_refresh` flag controls behavior at runtime
