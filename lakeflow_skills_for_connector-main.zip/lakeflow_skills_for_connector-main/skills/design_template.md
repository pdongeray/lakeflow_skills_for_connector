# Design Document Template

## Purpose
This template generates the mandatory design document (.md) that MUST be approved before any pipeline, notebook, or job is created. Supports both **batch** (full_refresh) and **streaming** (incremental/CDC) processing modes.

---

## Template Structure

```markdown
# Pipeline Design Document: {project_name}

## 1. Overview

| Attribute | Value |
|---|---|
| Project Name | {project_name} |
| Source System | {source_system} |
| Ingestion Method | {ingestion_method} (CDC / Query-Based) |
| Processing Modes | Batch (full_refresh) + Streaming (incremental) |
| Cloud | {cloud_provider} (AWS / Azure / GCP) |
| Compute | Serverless |
| Languages | PySpark + SQL |
| Pipeline Architecture | Two-Pipeline (Ingestion + Transformation) |
| Created Date | {current_date} |
| Status | PENDING APPROVAL |

## 2. Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│  Lakeflow Connect Managed Ingestion Pipeline                    │
│  (ingestion_definition — no code files)                         │
│                                                                 │
│  [{source_system}] ──► [{bronze_catalog}.{bronze_schema}.*]     │
│                         (Streaming Tables, auto-managed)         │
└─────────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│  SDP Transformation Pipeline                                    │
│  (libraries: [silver_transformations.py, gold_aggregations.sql])│
│                                                                 │
│  Bronze ──► Silver (Streaming Tables, @dp.table)                │
│  Silver ──► Gold (Streaming Tables, @dp.table + readStream)    │
└─────────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│  DQX Validation (Batch Notebook)                                │
│  Source vs Bronze │ Bronze vs Silver │ Silver vs Gold            │
└─────────────────────────────────────────────────────────────────┘
```

## 3. Processing Modes

### Selected Mode: {processing_mode} (Both | Streaming-first | Batch-only)

| Mode | Trigger | Behavior |
|------|---------|----------|
| **full_refresh** (Batch) | Manual or first run | Ingestion: full snapshot; Transformation: recompute all |
| **incremental** (Streaming) | Scheduled (continuous/micro-batch) | Ingestion: watermark-based delta; Transformation: from checkpoint |

### How Modes Work Per Layer

| Layer | Table Type | full_refresh Behavior | incremental Behavior |
|-------|-----------|----------------------|---------------------|
| Bronze (Ingestion) | Streaming Table | Full source snapshot | Cursor/watermark-based delta |
| Silver | Streaming Table | Truncate + recompute from bronze | Process ONLY new records from checkpoint |
| Gold (ALL types) | Streaming Table | Truncate + replay ALL from silver | Process ONLY new silver records from checkpoint |

### Processing Mode Decision Matrix

| Customer Scenario | run_mode | Silver Type | Gold Type | Behavior |
|---|---|---|---|---|
| Initial data load / full rebuild | full_refresh | Streaming Table | Streaming Table | Rebuild ALL from scratch |
| Daily/hourly scheduled runs | incremental | Streaming Table | Streaming Table | Process ONLY new records |
| Data recovery / reprocessing | full_refresh | Streaming Table | Streaming Table | Truncate + replay all |

**Key**: No code-level conditionals needed. SDP framework handles both modes via:
- `CREATE OR REFRESH STREAMING TABLE` + `STREAM()` wrapper — supports both full_refresh and incremental
- Pipeline `full_refresh` flag controls the behavior at runtime
- **Same pipeline code** works for both modes — NEVER use Materialized Views

## 4. Catalog & Schema Layout

| Layer | Catalog.Schema | Purpose |
|---|---|---|
| Bronze | {bronze_catalog}.{bronze_schema} | Raw ingestion from source (managed by Lakeflow Connect) |
| Silver | {silver_catalog}.{silver_schema} | Cleansed & transformed (SDP Streaming Tables) |
| Gold | {gold_catalog}.{gold_schema} | Business aggregations & KPIs (SDP Streaming Tables) |
| DQX | {dqx_catalog}.{dqx_schema} | Data quality validation results |

## 5. Ingestion Layer Configuration (Lakeflow Connect)

### 5.1 Connection Details
| Attribute | Value |
|---|---|
| Connection Name | {connection_name} |
| Source System Type | {source_system} |
| Ingestion Method | {ingestion_method} |
| Cursor Column | {cursor_column} (for Query-Based) |
| Gateway | {gateway_name} (for CDC-Based) |
| Pipeline Type | Managed Ingestion (`ingestion_definition`) |

### 5.2 Ingestion Pipeline Configuration

```json
{
  "name": "{source_system}_lakeflow_ingestion",
  "ingestion_definition": {
    "connection_name": "{connection_name}",
    "objects": [
      {"table": {"source_schema": "{source_schema}", "source_table": "{table_name}", "destination_catalog": "{bronze_catalog}", "destination_schema": "{bronze_schema}"}}
    ]
  },
  "serverless": true,
  "catalog": "{bronze_catalog}",
  "channel": "PREVIEW"
}
```

### 5.3 Supported Ingestion Methods

| Method | Use When | Watermark |
|--------|----------|-----------|
| **Query-Based** | Source has no native CDC; lighter setup | Cursor column (e.g., updated_at) |
| **CDC-Based** | Need lower latency + full change fidelity | Automatic (LSN/SCN/binlog) |
| **Foreign Catalog** | Already have Lakehouse Federation set up | N/A (reads in place) |

## 6. Silver Layer Design (SDP Streaming Tables)

### 6.1 Table Specifications

| Silver Table | Source (Bronze) | Table Type | Read Method |
|---|---|---|---|
| silver_{table_1} | {bronze_schema}.{table_1} | Streaming Table | spark.readStream.table() |
| silver_{table_2} | {bronze_schema}.{table_2} | Streaming Table | spark.readStream.table() |

### 6.2 Rules
- **Table Type**: Streaming Table (`@dp.table()`)
- **Read**: `spark.readStream.table("{bronze_catalog}.{bronze_schema}.{table}")` (fully qualified)
- **Clustering**: `cluster_by_auto=True` on ALL Silver tables
- **Both Modes**: Works for incremental (from checkpoint) AND full_refresh (recompute all)
- **Language**: Python (`.py` file) with `from pyspark import pipelines as dp`

### 6.3 Transformation Logic (per table)

| Silver Table | Transformations | Description |
|---|---|---|
| silver_{table_1} | initcap, trim, coalesce, derived columns | Business cleansing |
| silver_{table_2} | type casting, null handling, dedup | Data quality |

## 7. Gold Layer Design (SDP Streaming Tables)

### 7.1 Table Specifications

| Gold Table | Source (Silver) | Table Type | Read Method |
|---|---|---|---|
| gold_{entity_1} | silver_{table_1}, silver_{table_2} | Streaming Table | spark.readStream.table() / STREAM() |
| gold_{entity_2} | silver_{table_3} | Streaming Table | spark.readStream.table() / STREAM() |

### 7.2 Rules
- **Table Type**: Streaming Table (`@dp.table()` / `CREATE OR REFRESH STREAMING TABLE`) — NEVER Materialized View
- **Read**: `spark.readStream.table()` (Python) / `STREAM()` wrapper (SQL)
- **Clustering**: `cluster_by_auto=True` on ALL Gold tables
- **full_refresh**: Truncate + replay ALL from silver (complete rebuild)
- **incremental**: Resume from checkpoint, process ONLY new silver records
- **Language**: SQL (`.sql` file) preferred for clarity

### 7.3 Aggregation Logic

| Gold Table | Grain | Metrics | Joins |
|---|---|---|---|
| gold_{entity_1} | {grain} | {metrics} | {join_tables} |
| gold_{entity_2} | {grain} | {metrics} | {join_tables} |

## 8. DQX Validation Design

### 8.1 Validation Pairs

| # | Source Layer | Target Layer | Enabled |
|---|---|---|---|
| 1 | Source vs Bronze | Compare source counts with bronze | YES |
| 2 | Bronze vs Silver | Verify transformations applied correctly | YES |
| 3 | Silver vs Gold | Validate aggregation integrity | YES |

### 8.2 Rules
- Mode: BATCH only (queries materialized tables, NOT streams)
- Status: PASS or FAIL only
- Results Table: NEVER truncated (survives Full Refresh and Incremental)
- Clustering: CLUSTER BY AUTO on DQX output table

## 9. Orchestration Design (Lakeflow Job)

### 9.1 Job Configuration
| Attribute | Value |
|---|---|
| Job Name | {source_system}_ingestion_orchestration |
| Compute | Serverless |
| First Run | Full Refresh (both pipelines) |
| Subsequent Runs | Incremental (both pipelines) |
| Schedule | {schedule} |

### 9.2 Task Dependency DAG

```
[ingestion_pipeline (Lakeflow Connect)]
            │
            ▼
[transformation_pipeline (SDP: Silver + Gold)]
            │
            ▼
[dqx_validation (Notebook: all layers)]
            │
            ▼
[dqx_alerts (Notebook: send notifications)]
```

### 9.3 Task Definitions

| Task Key | Type | Depends On | Description |
|---|---|---|---|
| ingestion_pipeline | Pipeline Task | (none) | Lakeflow Connect: source → bronze |
| transformation_pipeline | Pipeline Task | ingestion_pipeline | SDP: bronze → silver → gold |
| dqx_validation | Notebook Task | transformation_pipeline | DQX validation across all layers |
| dqx_alerts | Notebook Task | dqx_validation | Alert notifications on failures |

### 9.4 Run Mode Handling

| Scenario | Ingestion Pipeline | Transformation Pipeline |
|----------|-------------------|------------------------|
| First Run | full_refresh=true | full_refresh=true |
| Scheduled Run | full_refresh=false (incremental) | full_refresh=false (incremental) |
| Data Issue Recovery | full_refresh=true | full_refresh=true |

## 10. Artifacts to be Created

| # | Artifact | Type | Path/Location |
|---|---|---|---|
| 1 | {source_system}_lakeflow_ingestion | Lakeflow Connect Pipeline | Pipeline (ingestion_definition) |
| 2 | {source_system}_sdp_pipeline | SDP Pipeline | Pipeline (libraries) |
| 3 | silver_transformations.py | Python file | {pipeline_root}/transformations/ |
| 4 | gold_aggregations.sql | SQL file | {pipeline_root}/transformations/ |
| 5 | {source_system}_dqx_validation | Notebook (PySpark) | {project_folder}/ |
| 6 | {source_system}_dqx_alerts | Notebook (PySpark) | {project_folder}/ |
| 7 | {source_system}_ingestion_orchestration | Lakeflow Job | N/A |

## 11. SDP Pipeline File Structure

```
{pipeline_root}/
└── transformations/
    ├── silver_transformations.py   # @dp.table() with spark.readStream
    └── gold_aggregations.sql       # CREATE OR REFRESH STREAMING TABLE + STREAM()
```

**Important Notes:**
- Bronze has NO code files — managed entirely by Lakeflow Connect
- Silver uses Python for complex transformations
- Gold uses SQL for clarity with aggregations
- No `%sql` magic — each file is single-language
- All table types support both batch and streaming via `OR REFRESH`

## 12. Error Handling

| Scenario | Action |
|---|---|
| Connection unavailable | Ingestion pipeline fails; transformation skipped (dependency) |
| Schema evolution | Lakeflow Connect handles automatically |
| Bronze table not found | Check ingestion pipeline ran successfully first |
| Permission errors | Report required GRANT statements |
| Full refresh needed | Trigger both pipelines with full_refresh=true |
```

---

## 13. Parameterization Design (Workspace Portability)

### Job-Level Parameters

| Category | Parameter | Default | Description |
|---|---|---|---|
| Catalog & Schema | bronze_catalog | {bronze_catalog} | Bronze layer catalog |
| Catalog & Schema | bronze_schema | {bronze_schema} | Bronze layer schema |
| Catalog & Schema | silver_catalog | {silver_catalog} | Silver layer catalog |
| Catalog & Schema | silver_schema | {silver_schema} | Silver layer schema |
| Catalog & Schema | gold_catalog | {gold_catalog} | Gold layer catalog |
| Catalog & Schema | gold_schema | {gold_schema} | Gold layer schema |
| Catalog & Schema | dqx_catalog | {dqx_catalog} | DQX results catalog |
| Catalog & Schema | dqx_schema | {dqx_schema} | DQX results schema |
| Ingestion | connection_name | {connection_name} | UC Connection name |
| Ingestion | source_database | {source_database} | Source database name |
| Ingestion | source_schema | {source_schema} | Source schema |
| Ingestion | cursor_column | {cursor_column} | Watermark column |
| Reference Assets | source_mapping_path | {source_mapping_path} | Source mapping doc location |
| Reference Assets | bronze_mapping_path | {bronze_mapping_path} | Bronze mapping doc location |
| Reference Assets | silver_sql_path | {silver_sql_path} | Silver SQL doc location |
| Reference Assets | gold_sql_path | {gold_sql_path} | Gold SQL doc location |
| Runtime | run_mode | incremental | full_refresh or incremental |
| Runtime | source_system | {source_system} | Source system identifier |
| Runtime | pipeline_name | {pipeline_name} | Pipeline project name |
| Alerting | alert_recipients | {emails} | Comma-separated email addresses |
| Alerting | project_folder | {project_path} | Workspace project folder |

### Parameter Flow Diagram

```
Job Parameters (editable in Job Settings UI)
    │
    ├──► Pipeline Tasks: pipeline_id (swap for new workspace)
    │
    ├──► Notebook Tasks: {{job.parameters.X}} → spark.conf.get("X")
    │
    └──► SDP Pipeline: configuration block (editable in Pipeline Settings)
              │
              └──► silver_transformations.py: spark.conf.get("bronze_catalog")
              └──► gold_aggregations.sql: ${silver_catalog}.${silver_schema}
```

### Workspace Portability Checklist

- [ ] Update job parameter defaults for new workspace
- [ ] Update SDP pipeline configuration block
- [ ] Update ingestion pipeline ingestion_definition (connection + destinations)
- [ ] Ensure UC Connection exists in target workspace
- [ ] Create required schemas in target catalog
- [ ] Upload reference documents to target Volume paths

---

## Agent Instructions

1. **Always generate this design document FIRST** before creating any artifacts
2. **Wait for user APPROVAL** before proceeding
3. **Two-pipeline architecture** is the default for Lakeflow Connect sources
4. **Gold = Streaming Tables** always (NEVER Materialized Views) — ensures true incremental at all layers
5. **No code for ingestion** — Lakeflow Connect is config-only
6. **Both modes supported** by default — no special configuration needed
7. **ALL values parameterized** — NEVER hard-code catalog/schema/connection/paths in code
8. **Job parameters flow down** to notebook tasks via `{{job.parameters.X}}` and to pipeline code via configuration block + `spark.conf.get()`
